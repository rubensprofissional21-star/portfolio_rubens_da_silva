#!/usr/bin/env node

import QRCode from 'qrcode';
import fs from 'fs';
import path from 'path';

// URL do app via Expo Go (usar a URL do dev server)
const EXPO_URL = 'exps://8081-iyi5bpyfhrndvzs6aev33-6b8980f7.us2.manus.computer';

// Criar diretório de output se não existir
const outputDir = path.join(process.cwd(), 'qr-codes');
if (!fs.existsSync(outputDir)) {
  fs.mkdirSync(outputDir, { recursive: true });
}

// Gerar QR Code como PNG
const qrPath = path.join(outputDir, 'app-qr-code.png');

QRCode.toFile(qrPath, EXPO_URL, {
  errorCorrectionLevel: 'H',
  type: 'image/png',
  width: 300,
  margin: 2,
  color: {
    dark: '#000000',
    light: '#FFFFFF',
  },
}, (err) => {
  if (err) {
    console.error('Erro ao gerar QR Code:', err);
    process.exit(1);
  }

  console.log('✅ QR Code gerado com sucesso!');
  console.log(`📱 Arquivo: ${qrPath}`);
  console.log(`🔗 URL: ${EXPO_URL}`);
  console.log('\n📖 Como usar:');
  console.log('1. Instale o Expo Go no seu dispositivo');
  console.log('2. Escaneie o QR Code com a câmera ou Expo Go');
  console.log('3. O app será carregado automaticamente');
});

// Também gerar versão em terminal (ASCII)
console.log('\n📲 QR Code (Terminal):');
QRCode.toString(EXPO_URL, {
  errorCorrectionLevel: 'L',
  type: 'terminal',
  width: 10,
}, (err, qrString) => {
  if (!err) {
    console.log(qrString);
  }
});
