/**
 * Game Screen - Tela principal de jogo com videoconferência e interface de RPG
 */

import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, FlatList } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { Button } from '@/components/ui/button';
import { TextInput } from '@/components/ui/text-input';
import { useGame } from '@/lib/context/game-context';
import { useColors } from '@/hooks/use-colors';
import { ChatMessage, NarrativeEvent } from '@/lib/domain/types';

export default function GameScreen() {
  const router = useRouter();
  const { roomId, nickname } = useLocalSearchParams<{ roomId: string; nickname: string }>();
  const { state, sendPlayerAction, leaveRoom } = useGame();
  const colors = useColors();

  const [activeTab, setActiveTab] = useState<'narrative' | 'chat' | 'character' | 'quests'>('narrative');
  const [playerMessage, setPlayerMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSendAction = async () => {
    if (!playerMessage.trim()) return;

    setIsLoading(true);
    try {
      await sendPlayerAction(playerMessage);
      setPlayerMessage('');
    } catch (error) {
      console.error('Erro ao enviar ação:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLeaveRoom = async () => {
    await leaveRoom();
    router.replace('/(tabs)');
  };

  if (!state) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">Carregando sala...</Text>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer className="p-0">
      <View className="flex-1 bg-background">
        {/* Header */}
        <View className="bg-surface border-b border-border p-4 flex-row items-center justify-between">
          <View>
            <Text className="text-lg font-bold text-foreground">
              {state.room.name}
            </Text>
            <Text className="text-xs text-muted">
              {state.room.currentPlayers.length}/{state.room.maxPlayers} jogadores
            </Text>
          </View>
          <Button
            label="Sair"
            variant="outline"
            size="small"
            onPress={handleLeaveRoom}
          />
        </View>

        {/* Main Content */}
        <View className="flex-1">
          {activeTab === 'narrative' && (
            <ScrollView className="flex-1 p-4" showsVerticalScrollIndicator={false}>
              <View className="gap-4">
                {state.narrativeHistory.length === 0 ? (
                  <View className="items-center justify-center py-8">
                    <Text className="text-2xl mb-2">🎭</Text>
                    <Text className="text-foreground font-semibold">
                      Aguardando narrativa...
                    </Text>
                    <Text className="text-sm text-muted text-center mt-2">
                      O Mestre de IA começará em breve
                    </Text>
                  </View>
                ) : (
                  state.narrativeHistory.map((event) => (
                    <NarrativeEventCard key={event.id} event={event} />
                  ))
                )}
              </View>
            </ScrollView>
          )}

          {activeTab === 'chat' && (
            <View className="flex-1">
              <ScrollView className="flex-1 p-4" showsVerticalScrollIndicator={false}>
                <View className="gap-3">
                  {state.chatHistory.length === 0 ? (
                    <View className="items-center justify-center py-8">
                      <Text className="text-2xl mb-2">💬</Text>
                      <Text className="text-foreground font-semibold">
                        Nenhuma mensagem ainda
                      </Text>
                    </View>
                  ) : (
                    state.chatHistory.map((msg) => (
                      <ChatBubble key={msg.id} message={msg} />
                    ))
                  )}
                </View>
              </ScrollView>
            </View>
          )}

          {activeTab === 'character' && (
            <ScrollView className="flex-1 p-4" showsVerticalScrollIndicator={false}>
              <CharacterSheet player={state.player} />
            </ScrollView>
          )}

          {activeTab === 'quests' && (
            <ScrollView className="flex-1 p-4" showsVerticalScrollIndicator={false}>
              <QuestList quests={state.quests} />
            </ScrollView>
          )}
        </View>

        {/* Tab Bar */}
        <View className="bg-surface border-t border-border flex-row">
          {(['narrative', 'chat', 'character', 'quests'] as const).map((tab) => (
            <Pressable
              key={tab}
              onPress={() => setActiveTab(tab)}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.7 : 1,
                  flex: 1,
                  borderBottomWidth: activeTab === tab ? 3 : 0,
                  borderBottomColor: activeTab === tab ? colors.primary : 'transparent',
                },
              ]}
              className="items-center justify-center py-3"
            >
              <Text
                className="text-xs font-semibold uppercase"
                style={{
                  color: activeTab === tab ? colors.primary : colors.muted,
                }}
              >
                {tab === 'narrative' && '📖'}
                {tab === 'chat' && '💬'}
                {tab === 'character' && '👤'}
                {tab === 'quests' && '⚔️'}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Input Area */}
        {activeTab === 'chat' && (
          <View className="bg-surface border-t border-border p-4 gap-2">
            <View className="flex-row gap-2 items-end">
              <TextInput
                placeholder="Sua ação ou mensagem..."
                value={playerMessage}
                onChangeText={setPlayerMessage}
                editable={!isLoading}
                containerClassName="flex-1"
              />
              <Button
                label="→"
                variant="primary"
                size="small"
                isLoading={isLoading}
                onPress={handleSendAction}
              />
            </View>
          </View>
        )}
      </View>
    </ScreenContainer>
  );
}

// Componentes auxiliares

function NarrativeEventCard({ event }: { event: NarrativeEvent }) {
  const colors = useColors();

  return (
    <View className="bg-surface rounded-lg p-4 border border-border gap-2">
      <View className="flex-row items-center justify-between">
        <Text className="text-xs font-semibold text-muted uppercase">
          {event.type === 'narration' && '📖 Narrativa'}
          {event.type === 'player_action' && '⚔️ Ação'}
          {event.type === 'npc_action' && '🎭 NPC'}
          {event.type === 'quest_update' && '⚔️ Quest'}
          {event.type === 'event' && '✨ Evento'}
        </Text>
        <Text className="text-xs text-muted">
          {new Date(event.timestamp).toLocaleTimeString()}
        </Text>
      </View>
      <Text className="text-sm text-foreground leading-relaxed">
        {event.content}
      </Text>
    </View>
  );
}

function ChatBubble({ message }: { message: ChatMessage }) {
  const colors = useColors();
  const isPlayer = message.sender === 'player';

  return (
    <View
      className={`flex-row gap-2 ${isPlayer ? 'justify-end' : 'justify-start'}`}
    >
      <View
        className={`max-w-xs rounded-lg p-3 ${
          isPlayer
            ? 'bg-primary'
            : 'bg-surface border border-border'
        }`}
      >
        <Text
          className="text-xs font-semibold mb-1"
          style={{
            color: isPlayer ? colors.background : colors.muted,
          }}
        >
          {message.senderName}
        </Text>
        <Text
          className="text-sm"
          style={{
            color: isPlayer ? colors.background : colors.foreground,
          }}
        >
          {message.content}
        </Text>
      </View>
    </View>
  );
}

function CharacterSheet({ player }: { player: any }) {
  if (!player.character) return null;

  const char = player.character;

  return (
    <View className="gap-4">
      <View className="bg-surface rounded-lg p-4 border border-border gap-3">
        <Text className="text-2xl font-bold text-foreground">
          {char.name}
        </Text>
        <View className="flex-row justify-between">
          <View>
            <Text className="text-xs text-muted">Classe</Text>
            <Text className="text-sm font-semibold text-foreground">
              {char.class}
            </Text>
          </View>
          <View>
            <Text className="text-xs text-muted">Nível</Text>
            <Text className="text-sm font-semibold text-foreground">
              {char.level}
            </Text>
          </View>
        </View>
      </View>

      <View className="bg-surface rounded-lg p-4 border border-border gap-2">
        <Text className="text-sm font-semibold text-foreground uppercase">
          Atributos
        </Text>
        <View className="gap-2">
          {Object.entries(char.attributes).map(([key, value]: [string, any]) => (
            <View key={key} className="flex-row justify-between">
              <Text className="text-sm text-muted capitalize">{key}</Text>
              <Text className="text-sm font-semibold text-foreground">
                {value}
              </Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

function QuestList({ quests }: { quests: any[] }) {
  if (quests.length === 0) {
    return (
      <View className="items-center justify-center py-8">
        <Text className="text-2xl mb-2">📜</Text>
        <Text className="text-foreground font-semibold">
          Nenhuma quest ativa
        </Text>
      </View>
    );
  }

  return (
    <View className="gap-3">
      {quests.map((quest) => (
        <View
          key={quest.id}
          className="bg-surface rounded-lg p-4 border border-border gap-2"
        >
          <Text className="text-sm font-semibold text-foreground">
            {quest.title}
          </Text>
          <Text className="text-xs text-muted">
            {quest.description}
          </Text>
          <View className="bg-background rounded h-2 mt-2 overflow-hidden">
            <View
              className="bg-primary h-full"
              style={{ width: `${quest.progress}%` }}
            />
          </View>
        </View>
      ))}
    </View>
  );
}
