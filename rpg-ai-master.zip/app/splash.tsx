/**
 * Splash Screen - Tela inicial com logo e animação de carregamento
 */

import React, { useEffect } from 'react';
import { View, Text, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { useColors } from '@/hooks/use-colors';

export default function SplashScreen() {
  const router = useRouter();
  const colors = useColors();

  useEffect(() => {
    // Simular carregamento de recursos
    const timer = setTimeout(() => {
      router.replace('/(tabs)');
    }, 2000);

    return () => clearTimeout(timer);
  }, [router]);

  return (
    <ScreenContainer containerClassName="bg-gradient-to-b from-background to-surface">
      <View className="flex-1 items-center justify-center gap-6">
        {/* Logo */}
        <View className="w-24 h-24 rounded-full bg-primary items-center justify-center">
          <Text className="text-5xl">🐉</Text>
        </View>

        {/* Título */}
        <View className="gap-2 items-center">
          <Text className="text-4xl font-bold text-foreground">
            RPG AI Master
          </Text>
          <Text className="text-base text-muted text-center">
            Aventuras narrativas com IA
          </Text>
        </View>

        {/* Loading */}
        <View className="mt-8">
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </View>
    </ScreenContainer>
  );
}
