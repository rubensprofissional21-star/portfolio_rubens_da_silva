/**
 * Join Room Screen - Tela para entrar em sala existente
 */

import React, { useState } from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { Button } from '@/components/ui/button';
import { TextInput } from '@/components/ui/text-input';
import { useGame } from '@/lib/context/game-context';
import { usePlayerSettings } from '@/hooks/use-player-settings';

export default function JoinRoomScreen() {
  const router = useRouter();
  const { joinRoom } = useGame();
  const { settings, updateNickname, addRecentRoom } = usePlayerSettings();

  const [roomCode, setRoomCode] = useState('');
  const [nickname, setNickname] = useState(settings.nickname);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleJoinRoom = async () => {
    setError('');

    if (!roomCode.trim()) {
      setError('Código da sala é obrigatório');
      return;
    }

    if (!nickname.trim()) {
      setError('Nickname é obrigatório');
      return;
    }

    setIsLoading(true);

    try {
      // Atualizar nickname se mudou
      if (nickname !== settings.nickname) {
        await updateNickname(nickname);
      }

      // Entrar na sala
      await joinRoom(`room_${roomCode}`, nickname);
      await addRecentRoom(`room_${roomCode}`);

      // Navegar para a tela de jogo integrada com Jitsi Meet
      router.push({
        pathname: '/game-integrated',
        params: { roomId: `room_${roomCode}`, nickname },
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erro ao entrar na sala');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 py-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">
              Entrar em Sala
            </Text>
            <Text className="text-base text-muted">
              Junte-se a uma aventura em andamento
            </Text>
          </View>

          {/* Info Box */}
          <View className="bg-surface rounded-2xl p-4 border border-border gap-2">
            <Text className="text-xs font-semibold text-muted uppercase">
              Dica
            </Text>
            <Text className="text-sm text-foreground">
              Peça o código da sala ao anfitrião. Geralmente tem 6-8 caracteres.
            </Text>
          </View>

          {/* Room Code Input */}
          <TextInput
            label="Código da Sala"
            placeholder="Ex: ABC123"
            value={roomCode}
            onChangeText={(text) => setRoomCode(text.toUpperCase())}
            editable={!isLoading}
            maxLength={20}
          />

          {/* Nickname Input */}
          <TextInput
            label="Seu Nickname"
            placeholder="Como você quer ser chamado?"
            value={nickname}
            onChangeText={setNickname}
            editable={!isLoading}
            maxLength={30}
          />

          {/* Error Message */}
          {error && (
            <View className="bg-error/10 border border-error rounded-lg p-3">
              <Text className="text-sm font-medium text-error">{error}</Text>
            </View>
          )}

          {/* Join Button */}
          <View className="gap-2 mt-4">
            <Button
              label="Entrar na Sala"
              variant="primary"
              size="large"
              isLoading={isLoading}
              onPress={handleJoinRoom}
            />
            <Button
              label="Cancelar"
              variant="outline"
              onPress={() => router.back()}
              disabled={isLoading}
            />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
