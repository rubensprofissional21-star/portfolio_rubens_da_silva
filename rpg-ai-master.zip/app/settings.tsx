/**
 * Settings Screen - Tela de configurações do app
 */

import React, { useState } from 'react';
import { ScrollView, Text, View, Pressable, Switch } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { Button } from '@/components/ui/button';
import { TextInput } from '@/components/ui/text-input';
import { usePlayerSettings } from '@/hooks/use-player-settings';
import { useColors } from '@/hooks/use-colors';
import { useColorScheme } from '@/hooks/use-color-scheme';

export default function SettingsScreen() {
  const router = useRouter();
  const { settings, updateNickname, updateTheme } = usePlayerSettings();
  const colors = useColors();
  const colorScheme = useColorScheme();

  const [nickname, setNickname] = useState(settings.nickname);
  const [audioEnabled, setAudioEnabled] = useState(settings.audioEnabled);
  const [videoEnabled, setVideoEnabled] = useState(settings.videoEnabled);
  const [hapticEnabled, setHapticEnabled] = useState(settings.hapticEnabled);

  const handleSaveNickname = async () => {
    if (nickname.trim()) {
      await updateNickname(nickname);
    }
  };

  const handleThemeChange = async (theme: 'light' | 'dark' | 'auto') => {
    await updateTheme(theme);
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 py-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">
              Configurações
            </Text>
            <Text className="text-base text-muted">
              Personalize sua experiência
            </Text>
          </View>

          {/* Profile Section */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground uppercase tracking-wider">
              Perfil
            </Text>
            <TextInput
              label="Nickname"
              placeholder="Seu nome de jogador"
              value={nickname}
              onChangeText={setNickname}
              containerClassName="mb-2"
            />
            <Button
              label="Salvar Nickname"
              variant="secondary"
              onPress={handleSaveNickname}
            />
          </View>

          {/* Theme Section */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground uppercase tracking-wider">
              Aparência
            </Text>
            <View className="gap-2">
              {(['light', 'dark', 'auto'] as const).map((theme) => (
                <Pressable
                  key={theme}
                  onPress={() => handleThemeChange(theme)}
                  style={({ pressed }) => [
                    {
                      opacity: pressed ? 0.7 : 1,
                      backgroundColor:
                        settings.theme === theme
                          ? colors.primary
                          : colors.surface,
                      borderColor:
                        settings.theme === theme
                          ? colors.primary
                          : colors.border,
                    },
                  ]}
                  className="flex-row items-center gap-3 p-4 rounded-lg border"
                >
                  <Text
                    className="flex-1 font-medium capitalize"
                    style={{
                      color:
                        settings.theme === theme
                          ? colors.background
                          : colors.foreground,
                    }}
                  >
                    {theme === 'auto' ? 'Automático' : theme === 'light' ? 'Claro' : 'Escuro'}
                  </Text>
                  {settings.theme === theme && (
                    <Text className="text-lg">✓</Text>
                  )}
                </Pressable>
              ))}
            </View>
          </View>

          {/* Audio/Video Section */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground uppercase tracking-wider">
              Mídia
            </Text>
            <View className="gap-3">
              <View className="flex-row items-center justify-between bg-surface rounded-lg p-4 border border-border">
                <Text className="text-base font-medium text-foreground">
                  Áudio Habilitado
                </Text>
                <Switch
                  value={audioEnabled}
                  onValueChange={setAudioEnabled}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={colors.background}
                />
              </View>
              <View className="flex-row items-center justify-between bg-surface rounded-lg p-4 border border-border">
                <Text className="text-base font-medium text-foreground">
                  Vídeo Habilitado
                </Text>
                <Switch
                  value={videoEnabled}
                  onValueChange={setVideoEnabled}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={colors.background}
                />
              </View>
              <View className="flex-row items-center justify-between bg-surface rounded-lg p-4 border border-border">
                <Text className="text-base font-medium text-foreground">
                  Feedback Háptico
                </Text>
                <Switch
                  value={hapticEnabled}
                  onValueChange={setHapticEnabled}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor={colors.background}
                />
              </View>
            </View>
          </View>

          {/* About Section */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground uppercase tracking-wider">
              Sobre
            </Text>
            <View className="bg-surface rounded-lg p-4 border border-border gap-2">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Versão</Text>
                <Text className="text-sm font-medium text-foreground">1.0.0</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Desenvolvido por</Text>
                <Text className="text-sm font-medium text-foreground">Manus AI</Text>
              </View>
            </View>
          </View>

          {/* Back Button */}
          <Button
            label="Voltar"
            variant="outline"
            onPress={() => router.back()}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
