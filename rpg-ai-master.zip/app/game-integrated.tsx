/**
 * Game Screen (Integrated) - Tela de jogo com Jitsi Meet integrado
 * Layout melhorado: Vídeo + Interface RPG lado a lado
 * Integrada com OpenAI para narrativas dinâmicas
 */

import React, { useState, useEffect, useRef } from 'react';
import { View, Text, ScrollView, Pressable, FlatList, Platform, TouchableOpacity, Dimensions } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { Button } from '@/components/ui/button';
import { TextInput } from '@/components/ui/text-input';
import { JitsiEmbeddedVideo } from '@/components/jitsi-embedded-video';
import { NarrativeRedesigned } from '@/components/narrative-redesigned';
import { RPGChatRedesigned, type ChatMessage } from '@/components/rpg-chat-redesigned';
import { CharacterSheetRedesigned } from '@/components/character-sheet-redesigned';
import { QuestsRedesigned } from '@/components/quests-redesigned';
import { useGame } from '@/lib/context/game-context';
import { useOpenAITRPC } from '@/hooks/use-openai-trpc';
import { useColors } from '@/hooks/use-colors';
import { useRPGTheme, RPGThemeProvider } from '@/components/rpg-theme-provider';
import { type RoomTheme, type NPC, type Quest } from '@/lib/domain/types';

function GameIntegratedScreenContent() {
  const router = useRouter();
  const { roomId, nickname } = useLocalSearchParams<{ roomId: string; nickname: string }>();
  const { state, sendPlayerAction, leaveRoom } = useGame();
  const { isLoading: aiLoading, error: aiError, generateNarrative, generateNPCs, generateQuest, respondToAction } = useOpenAITRPC();
  const colors = useColors();

  const [activeTab, setActiveTab] = useState<'narrative' | 'chat' | 'character' | 'quests'>('chat');
  const [playerMessage, setPlayerMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [narrativeText, setNarrativeText] = useState('');
  const [npcs, setNPCs] = useState<NPC[]>([]);
  const [quests, setQuests] = useState<Quest[]>([]);
  const scrollViewRef = useRef<ScrollView>(null);
  const [initialized, setInitialized] = useState(false);
  const screenWidth = Dimensions.get('window').width;
  const isLandscape = screenWidth > 800;

  // Inicializar IA com OpenAI
  useEffect(() => {
    const initialize = async () => {
      if (!state || !nickname || !roomId || initialized) return;

      try {
        console.log('Inicializando sessão com OpenAI...');
        
        // Gerar narrativa inicial
        const narrative = await generateNarrative(state.room.theme, state.room.difficulty);
        setNarrativeText(narrative);

        // Gerar NPCs
        const generatedNPCs = await generateNPCs(state.room.theme, 2);
        setNPCs(generatedNPCs);

        // Gerar primeira quest
        const firstQuest = await generateQuest(state.room.theme, state.room.difficulty);
        if (firstQuest) {
          setQuests([firstQuest]);
        }

        // Adicionar mensagem inicial do Mestre
        const initialMessage: ChatMessage = {
          id: `msg_${Date.now()}`,
          sender: 'master',
          content: `Bem-vindo, ${nickname}! Sua aventura começa agora. 🚀\n\n${narrative}`,
          timestamp: Date.now(),
          type: 'narrative',
        };
        setChatMessages([initialMessage]);
        setInitialized(true);

        console.log('Sessão inicializada com sucesso!');
      } catch (error) {
        console.error('Erro ao inicializar:', error);
        // Mostrar erro ao usuário
        const errorMessage: ChatMessage = {
          id: `msg_${Date.now()}`,
          sender: 'master',
          content: `⚠️ Erro ao conectar com a IA: ${aiError || 'Erro desconhecido'}. Verifique sua chave de API da OpenAI.`,
          timestamp: Date.now(),
          type: 'event',
        };
        setChatMessages([errorMessage]);
      }
    };

    initialize();
  }, [state, nickname, roomId, initialized, generateNarrative, generateNPCs, generateQuest, aiError]);

  /**
   * Enviar mensagem/ação ao Mestre de IA
   */
  const handleSendAction = async () => {
    if (!playerMessage.trim() || aiLoading) return;

    setIsLoading(true);
    try {
      // Adicionar mensagem do jogador
      const playerMsg: ChatMessage = {
        id: `msg_${Date.now()}`,
        sender: 'player',
        content: playerMessage,
        timestamp: Date.now(),
        type: 'action',
      };
      setChatMessages((prev) => [...prev, playerMsg]);
      setPlayerMessage('');

      // Obter resposta da IA
      const response = await respondToAction(playerMessage, narrativeText);
      const masterMsg: ChatMessage = {
        id: `msg_${Date.now() + 1}`,
        sender: 'master',
        content: response,
        timestamp: Date.now(),
        type: 'dialogue',
      };
      setChatMessages((prev) => [...prev, masterMsg]);

      // Scroll para a última mensagem
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    } catch (error) {
      console.error('Erro ao enviar ação:', error);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Executar ação rápida
   */
  const handleQuickAction = async (action: string) => {
    setPlayerMessage(action);
    // Simular envio
    setTimeout(() => {
      handleSendAction();
    }, 100);
  };

  /**
   * Sair da sala
   */
  const handleLeaveRoom = async () => {
    await leaveRoom();
    router.replace('/(tabs)');
  };

  if (!state || !roomId) {
    return (
      <ScreenContainer className="items-center justify-center">
        <Text className="text-foreground">Carregando...</Text>
      </ScreenContainer>
    );
  }

  return (
    <View className="flex-1 bg-gradient-to-b from-slate-900 to-slate-950">
      {/* Header */}
      <View className="bg-gradient-to-r from-purple-900 to-purple-800 border-b border-purple-700 px-4 py-3 flex-row items-center justify-between">
        <View className="flex-1">
          <Text className="text-lg font-bold text-purple-100">{state.room.name}</Text>
          <Text className="text-xs text-purple-300">{state.room.currentPlayers.length}/{state.room.maxPlayers} jogadores</Text>
        </View>
        <Pressable
          onPress={handleLeaveRoom}
          style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
          className="bg-gradient-to-b from-red-600 to-red-700 rounded-lg px-3 py-2 border border-red-500"
        >
          <Text className="text-white font-semibold text-sm">Sair</Text>
        </Pressable>
      </View>

      {/* Main Content - Layout responsivo */}
      <View className={`flex-1 ${isLandscape ? 'flex-row' : 'flex-col'}`}>
        {/* Videoconferência */}
        <View className={`${isLandscape ? 'w-1/2' : 'h-1/3'} border-r border-purple-700`}>
          <JitsiEmbeddedVideo roomName={roomId} displayName={nickname} />
        </View>

        {/* Interface de RPG */}
        <View className={`${isLandscape ? 'w-1/2' : 'flex-1'} flex-col bg-gradient-to-b from-slate-900 to-slate-950`}>
          {/* Abas */}
          <View className="flex-row border-b border-purple-700 bg-gradient-to-b from-slate-800 to-slate-900">
            {(['chat', 'narrative', 'character', 'quests'] as const).map((tab) => (
              <Pressable
                key={tab}
                onPress={() => setActiveTab(tab)}
                className={`flex-1 py-3 items-center border-b-2 ${
                  activeTab === tab ? 'border-purple-500 bg-gradient-to-b from-purple-900 to-purple-800' : 'border-transparent'
                }`}
              >
                <Text className={`text-lg ${
                  activeTab === tab ? 'text-purple-300' : 'text-purple-500'
                }`}>
                  {tab === 'chat' && '💬'}
                  {tab === 'narrative' && '📖'}
                  {tab === 'character' && '👤'}
                  {tab === 'quests' && '⚔️'}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* Conteúdo das abas */}
          <View className="flex-1">
            {activeTab === 'chat' && (
              <RPGChatRedesigned
                messages={chatMessages}
                onSendMessage={handleSendAction}
                onQuickAction={handleQuickAction}
                isLoading={isLoading}
                aiLoading={aiLoading}
                playerMessage={playerMessage}
                onPlayerMessageChange={setPlayerMessage}
              />
            )}
            {activeTab === 'narrative' && (
              <NarrativeRedesigned
                narrativeText={narrativeText}
                npcs={npcs}
                theme={state.room.theme}
              />
            )}
            {activeTab === 'character' && <CharacterSheetRedesigned character={state.player.character} />}
            {activeTab === 'quests' && <QuestsRedesigned quests={quests} />}
          </View>
        </View>
      </View>
    </View>
  );
}

export default function GameIntegratedScreen() {
  return (
    <RPGThemeProvider theme="medieval">
      <GameIntegratedScreenContent />
    </RPGThemeProvider>
  );
}
