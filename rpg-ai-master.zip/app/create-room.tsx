/**
 * Create Room Screen - Tela para criar nova sala de RPG
 */

import React, { useState } from 'react';
import { ScrollView, Text, View, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { ScreenContainer } from '@/components/screen-container';
import { Button } from '@/components/ui/button';
import { TextInput } from '@/components/ui/text-input';
import { useGame } from '@/lib/context/game-context';
import { usePlayerSettings } from '@/hooks/use-player-settings';
import { useColors } from '@/hooks/use-colors';
import { RoomTheme, Difficulty } from '@/lib/domain/types';

const THEMES: { id: RoomTheme; label: string; emoji: string }[] = [
  { id: 'medieval', label: 'Fantasia Medieval', emoji: '🏰' },
  { id: 'scifi', label: 'Ficção Científica', emoji: '🚀' },
  { id: 'horror', label: 'Horror', emoji: '👻' },
  { id: 'fantasy', label: 'Fantasia', emoji: '✨' },
];

const DIFFICULTIES: { id: Difficulty; label: string }[] = [
  { id: 'easy', label: 'Fácil' },
  { id: 'normal', label: 'Normal' },
  { id: 'hard', label: 'Difícil' },
];

export default function CreateRoomScreen() {
  const router = useRouter();
  const { createRoom, state } = useGame();
  const { settings, addRecentRoom } = usePlayerSettings();
  const colors = useColors();

  const [roomName, setRoomName] = useState('');
  const [selectedTheme, setSelectedTheme] = useState<RoomTheme>('medieval');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>('normal');
  const [maxPlayers, setMaxPlayers] = useState('4');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleCreateRoom = async () => {
    setError('');

    if (!roomName.trim()) {
      setError('Nome da sala é obrigatório');
      return;
    }

    if (parseInt(maxPlayers) < 2 || parseInt(maxPlayers) > 10) {
      setError('Máximo de jogadores deve estar entre 2 e 10');
      return;
    }

    setIsLoading(true);

    try {
      const room = await createRoom(
        roomName,
        selectedTheme,
        selectedDifficulty,
        parseInt(maxPlayers)
      );

      await addRecentRoom(room.id);

      // Navegar para a tela de jogo integrada com Jitsi Meet
      router.push({
        pathname: '/game-integrated',
        params: { roomId: room.id, nickname: settings.nickname },
      });
    } catch (err) {
      setError('Erro ao criar sala. Tente novamente.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer className="p-6">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="gap-6 py-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-3xl font-bold text-foreground">
              Criar Sala
            </Text>
            <Text className="text-base text-muted">
              Configure sua aventura de RPG
            </Text>
          </View>

          {/* Room Name */}
          <TextInput
            label="Nome da Sala"
            placeholder="Ex: A Taverna do Dragão"
            value={roomName}
            onChangeText={setRoomName}
            editable={!isLoading}
          />

          {/* Theme Selection */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">
              Tema da Aventura
            </Text>
            <View className="gap-2">
              {THEMES.map((theme) => (
                <Pressable
                  key={theme.id}
                  onPress={() => setSelectedTheme(theme.id)}
                  style={({ pressed }) => [
                    {
                      opacity: pressed ? 0.7 : 1,
                      backgroundColor:
                        selectedTheme === theme.id
                          ? colors.primary
                          : colors.surface,
                      borderColor:
                        selectedTheme === theme.id
                          ? colors.primary
                          : colors.border,
                    },
                  ]}
                  className="flex-row items-center gap-3 p-4 rounded-lg border"
                >
                  <Text className="text-2xl">{theme.emoji}</Text>
                  <Text
                    className="flex-1 font-medium"
                    style={{
                      color:
                        selectedTheme === theme.id
                          ? colors.background
                          : colors.foreground,
                    }}
                  >
                    {theme.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Difficulty Selection */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">
              Dificuldade
            </Text>
            <View className="flex-row gap-2">
              {DIFFICULTIES.map((difficulty) => (
                <Pressable
                  key={difficulty.id}
                  onPress={() => setSelectedDifficulty(difficulty.id)}
                  style={({ pressed }) => [
                    {
                      opacity: pressed ? 0.7 : 1,
                      backgroundColor:
                        selectedDifficulty === difficulty.id
                          ? colors.primary
                          : colors.surface,
                      borderColor:
                        selectedDifficulty === difficulty.id
                          ? colors.primary
                          : colors.border,
                      flex: 1,
                    },
                  ]}
                  className="items-center p-3 rounded-lg border"
                >
                  <Text
                    className="font-medium"
                    style={{
                      color:
                        selectedDifficulty === difficulty.id
                          ? colors.background
                          : colors.foreground,
                    }}
                  >
                    {difficulty.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          {/* Max Players */}
          <TextInput
            label="Máximo de Jogadores"
            placeholder="2-10"
            value={maxPlayers}
            onChangeText={setMaxPlayers}
            keyboardType="number-pad"
            editable={!isLoading}
          />

          {/* Error Message */}
          {error && (
            <View className="bg-error/10 border border-error rounded-lg p-3">
              <Text className="text-sm font-medium text-error">{error}</Text>
            </View>
          )}

          {/* Create Button */}
          <View className="gap-2 mt-4">
            <Button
              label="Criar Sala"
              variant="primary"
              size="large"
              isLoading={isLoading}
              onPress={handleCreateRoom}
            />
            <Button
              label="Cancelar"
              variant="outline"
              onPress={() => router.back()}
              disabled={isLoading}
            />
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
