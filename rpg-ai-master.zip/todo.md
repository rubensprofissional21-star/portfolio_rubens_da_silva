# RPG AI Master - TODO

## Fase 1: Autenticação e Entrada
- [x] Tela de Splash com logo do app
- [x] Tela de Entrada (Home) com opções de criar/entrar em sala
- [x] Tela de Criação de Sala (nome, tema, dificuldade, max players)
- [x] Tela de Entrada em Sala (código, nickname)
- [x] Validação de entrada de dados
- [x] Armazenamento local de nickname (AsyncStorage)
- [ ] Histórico de sessões recentes (opcional)

## Fase 2: Integração com Jitsi Meet
- [x] Instalação e configuração do Jitsi Meet SDK (serviço criado)
- [x] Embed do Jitsi Meet na tela de jogo
- [x] Controles de áudio/vídeo
- [ ] Gerenciamento de participantes
- [ ] Tratamento de erros de conexão
- [x] Encerramento de videoconferência

## Fase 3: Mestre de IA (Core)
- [x] Integração com API de IA (simulada, pronta para OpenAI)
- [x] Geração de narrativa inicial baseada no tema
- [x] Sistema de prompts para IA
- [x] Geração de NPCs (nome, personalidade, história)
- [x] Geração de Quests (objetivos, recompensas, conflitos)
- [x] Geração de eventos dinâmicos
- [x] Adaptação de história baseada em ações dos jogadores
- [ ] Cache de respostas para otimização

## Fase 4: Interface de Jogo
- [x] Tela de Narrativa (exibição de eventos)
- [x] Tela de Chat (interação com Mestre)
- [x] Botões de Ação Rápida (Atacar, Defender, Falar, etc.)
- [x] Tela de Personagem (atributos, inventário)
- [x] Tela de Quests (lista de objetivos)
- [x] Tab bar para navegação entre abas
- [x] Scroll infinito de histórico de narrativa
- [x] Indicador de digitação do Mestre

## Fase 5: Sistema de Sessão
- [x] Criação de salas com ID único
- [x] Persistência de estado da sessão (AsyncStorage)
- [ ] Sincronização de estado entre jogadores (opcional)
- [ ] Histórico de sessões completadas
- [ ] Exportação de sessão (JSON/PDF)
- [ ] Retomada de sessão interrompida

## Fase 6: Assets Visuais
- [x] Geração de logo do app
- [x] Ícones para tabs e botões
- [ ] Imagens temáticas (medieval, sci-fi, horror)
- [x] Splash screen
- [x] Favicon

## Fase 7: Documentação
- [x] README.md profissional
- [x] Instruções de instalação
- [x] Como rodar o projeto
- [x] Estrutura do projeto
- [ ] Guia de contribuição
- [x] Geração de QR Code para teste

## Fase 8: Testes e Polimento
- [ ] Testes unitários (hooks, services)
- [ ] Testes de integração (fluxos)
- [ ] Testes de performance
- [ ] Correção de bugs
- [ ] Otimização de performance
- [ ] Tratamento de erros
- [ ] Validação de acessibilidade

## Fase 9: Entrega Final
- [x] Geração de QR Code para instalação
- [x] Documentação completa
- [x] Assets visuais finalizados
- [x] Fluxo de navegação corrigido (criar sala → jogo integrado)
- [x] Fluxo de navegação corrigido (entrar em sala → jogo integrado)
- [ ] Checkpoint final e publicação

## Extras (Se Possível)
- [ ] Sistema de escolhas com impacto na história
- [ ] Customização de personagem (classe, atributos)
- [ ] Geração de avatares
- [ ] Efeitos sonoros
- [ ] Música de fundo temática
- [ ] Animações de transição
- [ ] Suporte a múltiplos idiomas
