#!/usr/bin/env python3
from PIL import Image
import os

os.chdir('/home/ubuntu/rpg-ai-master/assets/images')

images = [
    'hero-banner.png',
    'card-create-room.png',
    'card-join-room.png',
    'card-ai-master.png'
]

for img_name in images:
    if os.path.exists(img_name):
        print(f"Comprimindo {img_name}...")
        img = Image.open(img_name)
        
        # Redimensionar para max 1024px mantendo aspect ratio
        img.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
        
        # Salvar com otimização
        img.save(img_name, 'PNG', optimize=True)
        
        size_kb = os.path.getsize(img_name) / 1024
        print(f"✓ {img_name}: {size_kb:.1f} KB")
    else:
        print(f"✗ {img_name}: não encontrado")

print("\nCompressão concluída!")
