# Design do RPG AI Master

## Visão Geral
RPG AI Master é uma plataforma de RPG de mesa online que integra videoconferência (Jitsi Meet) com um Mestre de RPG controlado por Inteligência Artificial. O diferencial é a experiência narrativa imersiva com IA generativa conduzindo a história em tempo real.

## Orientação de Design
- **Orientação**: Portrait (9:16) - otimizado para uso com uma mão
- **Padrão**: Apple Human Interface Guidelines (HIG) - deve parecer um app iOS nativo de primeira parte
- **Paleta de Cores**: Tema épico de fantasia medieval com tons escuros e acentos dourados

---

## Paleta de Cores

| Token | Light | Dark | Uso |
|-------|-------|------|-----|
| `primary` | #8B6914 | #D4AF37 | Botões principais, acentos, ações |
| `background` | #FFFFFF | #0F0F0F | Fundo geral das telas |
| `surface` | #F5F5F5 | #1A1A1A | Cards, superfícies elevadas |
| `foreground` | #1A1A1A | #F5F5F5 | Texto principal |
| `muted` | #666666 | #999999 | Texto secundário, labels |
| `border` | #E0E0E0 | #333333 | Divisores, bordas |
| `success` | #22C55E | #4ADE80 | Ações bem-sucedidas |
| `warning` | #F59E0B | #FBBF24 | Avisos |
| `error` | #EF4444 | #F87171 | Erros |

---

## Telas Principais

### 1. **Splash / Onboarding**
- Logo do app (ícone épico de RPG)
- Animação de carregamento
- Mensagem de boas-vindas

### 2. **Tela de Entrada (Home)**
- Opção: Criar nova sala de RPG
- Opção: Entrar em sala existente (com código)
- Campo de nickname/nome do jogador
- Histórico de sessões recentes (opcional)

### 3. **Criação de Sala**
- Nome da sala
- Tema (Fantasia Medieval, Sci-Fi, Horror, etc.)
- Dificuldade (Fácil, Normal, Difícil)
- Número máximo de jogadores
- Botão "Criar Sala"

### 4. **Entrada em Sala**
- Campo para código da sala
- Campo de nickname
- Botão "Entrar"

### 5. **Sala de Jogo (Main Screen)**
- **Topo**: Informações da sessão (tema, dificuldade, número de jogadores)
- **Centro**: Área de videoconferência (Jitsi Meet embed)
- **Lado Esquerdo**: Chat com Mestre de IA
- **Botões de Ação**: Decisões rápidas dos jogadores
- **Abas**: Narrativa, Chat, Personagem, Quests

### 6. **Tela de Narrativa**
- Histórico de eventos narrados pela IA
- Descrição do cenário atual
- NPCs presentes
- Scroll vertical para histórico completo

### 7. **Tela de Chat**
- Mensagens do Mestre de IA
- Respostas dos jogadores
- Sugestões de ações rápidas
- Campo de entrada de texto

### 8. **Tela de Personagem**
- Nome e classe do personagem
- Atributos (Força, Inteligência, Destreza, etc.)
- Inventário
- Histórico de ações

### 9. **Tela de Quests**
- Lista de quests ativas
- Objetivos e recompensas
- Status de progresso
- Histórico de quests completadas

### 10. **Tela de Configurações**
- Volume de áudio/vídeo
- Tema (claro/escuro)
- Sair da sala
- Sobre o app

---

## Fluxos de Usuário Principais

### Fluxo 1: Criar e Entrar em uma Sessão
1. Usuário abre o app
2. Na tela de entrada, toca "Criar Sala"
3. Preenche dados (nome, tema, dificuldade)
4. Toca "Criar Sala"
5. É redirecionado para a sala de jogo
6. Videoconferência é inicializada
7. Mestre de IA começa a narrar

### Fluxo 2: Entrar em Sala Existente
1. Usuário abre o app
2. Na tela de entrada, toca "Entrar em Sala"
3. Insere código da sala
4. Insere nickname
5. Toca "Entrar"
6. É redirecionado para a sala de jogo
7. Vê o histórico de narrativa até o momento

### Fluxo 3: Interagir com o Mestre de IA
1. Usuário está na sala de jogo
2. Vê a narrativa atual
3. Escolhe uma ação (via botões ou chat)
4. Envia a ação
5. Mestre de IA processa e gera resposta
6. Narrativa é atualizada
7. Novos eventos/NPCs são gerados dinamicamente

### Fluxo 4: Sair da Sessão
1. Usuário toca botão "Sair"
2. Confirma ação
3. Videoconferência é encerrada
4. Retorna à tela de entrada
5. Sessão é salva no histórico

---

## Componentes Principais

### Componentes de UI
- **Header**: Título da tela, botões de ação
- **Card**: Container para narrativa, NPCs, quests
- **Button**: Botões de ação primária e secundária
- **Input**: Campos de texto (nome, código, mensagens)
- **Tab Bar**: Navegação entre abas (Narrativa, Chat, Personagem, Quests)
- **Chat Bubble**: Mensagens do Mestre e do Jogador
- **Video Container**: Embed do Jitsi Meet
- **Action Button**: Botões de ação rápida (Atacar, Defender, Falar, etc.)

### Componentes de Negócio
- **RoomManager**: Gerencia criação e entrada em salas
- **AIGameMaster**: Orquestra a IA para narrativa, NPCs, quests
- **VideoConference**: Integração com Jitsi Meet
- **ChatManager**: Gerencia conversas com o Mestre
- **PlayerState**: Rastreia estado do jogador (atributos, inventário, etc.)
- **SessionPersistence**: Salva e carrega estado da sessão

---

## Padrões de Interação

### Feedback Visual
- **Botões**: Escala 0.97 ao pressionar + haptic feedback leve
- **Cards**: Opacidade 0.7 ao pressionar
- **Ícones**: Opacidade 0.6 ao pressionar

### Animações (Subtis)
- Fade-in de narrativa: 250ms
- Slide-in de mensagens: 200ms
- Transição de abas: 150ms

### Notificações
- Toast para ações bem-sucedidas
- Alerta para erros
- Badge para novas mensagens do Mestre

---

## Arquitetura de Dados

### Entidades Principais
```
Room {
  id: string
  name: string
  theme: 'medieval' | 'scifi' | 'horror' | 'fantasy'
  difficulty: 'easy' | 'normal' | 'hard'
  maxPlayers: number
  currentPlayers: Player[]
  createdAt: timestamp
  narrativeHistory: NarrativeEvent[]
}

Player {
  id: string
  nickname: string
  character: Character
  joinedAt: timestamp
}

Character {
  name: string
  class: string
  level: number
  attributes: {
    strength: number
    intelligence: number
    dexterity: number
    constitution: number
    wisdom: number
    charisma: number
  }
  inventory: Item[]
  health: number
  maxHealth: number
}

NarrativeEvent {
  id: string
  timestamp: timestamp
  type: 'narration' | 'npc_action' | 'player_action' | 'quest_update'
  content: string
  npc?: NPC
  quest?: Quest
}

NPC {
  id: string
  name: string
  personality: string
  backstory: string
  currentMood: string
  relationships: { [playerId]: string }
}

Quest {
  id: string
  title: string
  description: string
  objectives: string[]
  rewards: Reward[]
  status: 'active' | 'completed' | 'failed'
  progress: number
}

Reward {
  type: 'experience' | 'gold' | 'item'
  amount: number
  item?: Item
}

Item {
  id: string
  name: string
  description: string
  rarity: 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary'
}
```

---

## Fluxo de Dados (Clean Architecture)

```
UI Layer (React Components)
    ↓
ViewModel Layer (Hooks + Context)
    ↓
Domain Layer (Business Logic)
    ↓
Data Layer (API + Local Storage)
```

### Exemplo: Enviar Ação do Jogador
1. UI: Jogador toca botão "Atacar"
2. ViewModel: `useGameMaster()` chama `sendPlayerAction()`
3. Domain: `GameMasterService.processAction()` valida e enriquece ação
4. Data: `AIService.generateResponse()` chama API de IA
5. Domain: `NarrativeGenerator.createNarrativeEvent()` cria evento
6. ViewModel: Atualiza estado com novo evento
7. UI: Renderiza narrativa atualizada

---

## Considerações de UX/UI

### Acessibilidade
- Contraste de cores WCAG AA
- Tamanho de fonte mínimo 16sp
- Espaçamento adequado entre elementos
- Suporte a VoiceOver (iOS) e TalkBack (Android)

### Performance
- Lazy loading de histórico de narrativa
- Virtualização de listas (FlatList)
- Memoização de componentes pesados
- Compressão de imagens

### Responsividade
- Layout adapta-se a diferentes tamanhos de tela
- Orientação portrait como padrão
- Suporte a notch/safe area

### Offline
- Armazenamento local de sessão
- Sincronização quando conectado
- Mensagens de erro claras

---

## Próximas Fases

1. **Fase 1**: Autenticação e criação de salas
2. **Fase 2**: Integração com Jitsi Meet
3. **Fase 3**: Mestre de IA com narrativa
4. **Fase 4**: Interface de jogo completa
5. **Fase 5**: Persistência e histórico
6. **Fase 6**: Polimento e testes
