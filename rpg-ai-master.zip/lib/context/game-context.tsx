/**
 * Game Context - Gerencia estado global da sessão de RPG
 * Implementa padrão de Context + useReducer para Clean Architecture
 */

import React, { createContext, useReducer, ReactNode, useCallback } from 'react';
import { Room, Player, Character, SessionState, AppSettings, NarrativeEvent, ChatMessage, Quest, NPC, QuickAction } from '@/lib/domain/types';
import AsyncStorage from '@react-native-async-storage/async-storage';

type GameAction =
  | { type: 'SET_ROOM'; payload: Room }
  | { type: 'SET_PLAYER'; payload: Player }
  | { type: 'ADD_NARRATIVE_EVENT'; payload: NarrativeEvent }
  | { type: 'ADD_CHAT_MESSAGE'; payload: ChatMessage }
  | { type: 'UPDATE_QUESTS'; payload: Quest[] }
  | { type: 'UPDATE_NPCS'; payload: NPC[] }
  | { type: 'SET_QUICK_ACTIONS'; payload: QuickAction[] }
  | { type: 'SET_CONNECTION_STATUS'; payload: boolean }
  | { type: 'SET_MASTER_RESPONDING'; payload: boolean }
  | { type: 'RESET_SESSION' };

interface GameContextType {
  state: SessionState | null;
  dispatch: React.Dispatch<GameAction>;
  createRoom: (name: string, theme: string, difficulty: string, maxPlayers: number) => Promise<Room>;
  joinRoom: (roomId: string, nickname: string) => Promise<void>;
  leaveRoom: () => Promise<void>;
  sendPlayerAction: (action: string) => Promise<void>;
  updateSettings: (settings: Partial<AppSettings>) => Promise<void>;
}

const initialState: SessionState = {
  roomId: '',
  playerId: '',
  room: {} as Room,
  player: {} as Player,
  narrativeHistory: [],
  chatHistory: [],
  quests: [],
  npcs: [],
  quickActions: [],
  isConnected: false,
  isMasterResponding: false,
};

export const GameContext = createContext<GameContextType | undefined>(undefined);

function gameReducer(state: SessionState, action: GameAction): SessionState {
  switch (action.type) {
    case 'SET_ROOM':
      return { ...state, room: action.payload, roomId: action.payload.id };
    case 'SET_PLAYER':
      return { ...state, player: action.payload, playerId: action.payload.id };
    case 'ADD_NARRATIVE_EVENT':
      return {
        ...state,
        narrativeHistory: [...state.narrativeHistory, action.payload],
      };
    case 'ADD_CHAT_MESSAGE':
      return {
        ...state,
        chatHistory: [...state.chatHistory, action.payload],
      };
    case 'UPDATE_QUESTS':
      return { ...state, quests: action.payload };
    case 'UPDATE_NPCS':
      return { ...state, npcs: action.payload };
    case 'SET_QUICK_ACTIONS':
      return { ...state, quickActions: action.payload };
    case 'SET_CONNECTION_STATUS':
      return { ...state, isConnected: action.payload };
    case 'SET_MASTER_RESPONDING':
      return { ...state, isMasterResponding: action.payload };
    case 'RESET_SESSION':
      return initialState;
    default:
      return state;
  }
}

export function GameProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  const createRoom = useCallback(async (name: string, theme: string, difficulty: string, maxPlayers: number): Promise<Room> => {
    const roomId = `room_${Date.now()}`;
    const room: Room = {
      id: roomId,
      name,
      theme: theme as any,
      difficulty: difficulty as any,
      maxPlayers,
      currentPlayers: [],
      createdAt: Date.now(),
      narrativeHistory: [],
      status: 'waiting',
    };

    // Salvar sala no AsyncStorage
    await AsyncStorage.setItem(`room_${roomId}`, JSON.stringify(room));

    dispatch({ type: 'SET_ROOM', payload: room });
    return room;
  }, []);

  const joinRoom = useCallback(async (roomId: string, nickname: string): Promise<void> => {
    // Simular carregamento de sala
    const roomData = await AsyncStorage.getItem(`room_${roomId}`);
    if (!roomData) {
      throw new Error('Sala não encontrada');
    }

    const room: Room = JSON.parse(roomData);
    const playerId = `player_${Date.now()}`;

    const character: Character = {
      id: `char_${playerId}`,
      name: nickname,
      class: 'Aventureiro',
      level: 1,
      experience: 0,
      attributes: {
        strength: 10,
        intelligence: 10,
        dexterity: 10,
        constitution: 10,
        wisdom: 10,
        charisma: 10,
      },
      inventory: [],
      health: 20,
      maxHealth: 20,
      mana: 10,
      maxMana: 10,
    };

    const player: Player = {
      id: playerId,
      nickname,
      character,
      joinedAt: Date.now(),
      isHost: room.currentPlayers.length === 0,
    };

    room.currentPlayers.push(player);
    await AsyncStorage.setItem(`room_${roomId}`, JSON.stringify(room));

    dispatch({ type: 'SET_ROOM', payload: room });
    dispatch({ type: 'SET_PLAYER', payload: player });
    dispatch({ type: 'SET_CONNECTION_STATUS', payload: true });
  }, []);

  const leaveRoom = useCallback(async (): Promise<void> => {
    if (state && state.roomId && state.playerId) {
      const roomData = await AsyncStorage.getItem(`room_${state.roomId}`);
      if (roomData) {
        const room: Room = JSON.parse(roomData);
        room.currentPlayers = room.currentPlayers.filter(p => p.id !== state.playerId);
        await AsyncStorage.setItem(`room_${state.roomId}`, JSON.stringify(room));
      }
    }

    dispatch({ type: 'RESET_SESSION' });
  }, [state]);

  const sendPlayerAction = useCallback(async (action: string): Promise<void> => {
    if (!state) return;

    // Adicionar ação do jogador ao histórico
    const event: NarrativeEvent = {
      id: `event_${Date.now()}`,
      timestamp: Date.now(),
      type: 'player_action',
      content: action,
      playerId: state.playerId,
      playerAction: action,
    };

    dispatch({ type: 'ADD_NARRATIVE_EVENT', payload: event });

    // Simular resposta do Mestre (será substituído por IA real)
    dispatch({ type: 'SET_MASTER_RESPONDING', payload: true });
    setTimeout(() => {
      const masterResponse: NarrativeEvent = {
        id: `event_${Date.now()}`,
        timestamp: Date.now(),
        type: 'narration',
        content: `O Mestre observa sua ação: "${action}". A história continua...`,
      };
      dispatch({ type: 'ADD_NARRATIVE_EVENT', payload: masterResponse });
      dispatch({ type: 'SET_MASTER_RESPONDING', payload: false });
    }, 1000);
  }, [state]);

  const updateSettings = useCallback(async (settings: Partial<AppSettings>): Promise<void> => {
    const currentSettings = await AsyncStorage.getItem('app_settings');
    const merged = { ...JSON.parse(currentSettings || '{}'), ...settings };
    await AsyncStorage.setItem('app_settings', JSON.stringify(merged));
  }, []);

  const value: GameContextType = {
    state: state.roomId ? state : null,
    dispatch,
    createRoom,
    joinRoom,
    leaveRoom,
    sendPlayerAction,
    updateSettings,
  };

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const context = React.useContext(GameContext);
  if (!context) {
    throw new Error('useGame deve ser usado dentro de GameProvider');
  }
  return context;
}
