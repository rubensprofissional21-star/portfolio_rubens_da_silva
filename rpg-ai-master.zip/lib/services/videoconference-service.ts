/**
 * Videoconference Service - Gerencia integração com Jitsi Meet
 * Implementa padrão de Service Layer (Clean Architecture)
 */

export interface VideoConferenceConfig {
  roomId: string;
  displayName: string;
  serverURL?: string;
  subject?: string;
  audioOnly?: boolean;
  videoMuted?: boolean;
  audioMuted?: boolean;
}

export interface VideoConferenceState {
  isConnected: boolean;
  isAudioMuted: boolean;
  isVideoMuted: boolean;
  participantCount: number;
  error?: string;
}

/**
 * Serviço de Videoconferência
 * Encapsula lógica de conexão e controle do Jitsi Meet
 */
export class VideoConferenceService {
  private config: VideoConferenceConfig | null = null;
  private state: VideoConferenceState = {
    isConnected: false,
    isAudioMuted: false,
    isVideoMuted: false,
    participantCount: 0,
  };
  private listeners: Set<(state: VideoConferenceState) => void> = new Set();

  /**
   * Inicializar conexão de videoconferência
   */
  async initialize(config: VideoConferenceConfig): Promise<void> {
    try {
      this.config = config;

      // Simular inicialização (será substituído por Jitsi SDK real)
      await this.simulateConnection();

      this.state = {
        ...this.state,
        isConnected: true,
        participantCount: 1,
      };

      this.notifyListeners();
    } catch (error) {
      this.state = {
        ...this.state,
        error: error instanceof Error ? error.message : 'Erro ao conectar',
      };
      throw error;
    }
  }

  /**
   * Desconectar de videoconferência
   */
  async disconnect(): Promise<void> {
    try {
      // Simular desconexão
      await this.simulateDisconnection();

      this.state = {
        isConnected: false,
        isAudioMuted: false,
        isVideoMuted: false,
        participantCount: 0,
      };

      this.config = null;
      this.notifyListeners();
    } catch (error) {
      console.error('Erro ao desconectar:', error);
    }
  }

  /**
   * Ativar/desativar áudio
   */
  async toggleAudio(muted: boolean): Promise<void> {
    if (!this.state.isConnected) {
      throw new Error('Não conectado à videoconferência');
    }

    try {
      // Simular toggle de áudio
      await this.simulateAudioToggle(muted);

      this.state = {
        ...this.state,
        isAudioMuted: muted,
      };

      this.notifyListeners();
    } catch (error) {
      console.error('Erro ao alternar áudio:', error);
      throw error;
    }
  }

  /**
   * Ativar/desativar vídeo
   */
  async toggleVideo(muted: boolean): Promise<void> {
    if (!this.state.isConnected) {
      throw new Error('Não conectado à videoconferência');
    }

    try {
      // Simular toggle de vídeo
      await this.simulateVideoToggle(muted);

      this.state = {
        ...this.state,
        isVideoMuted: muted,
      };

      this.notifyListeners();
    } catch (error) {
      console.error('Erro ao alternar vídeo:', error);
      throw error;
    }
  }

  /**
   * Obter estado atual
   */
  getState(): VideoConferenceState {
    return { ...this.state };
  }

  /**
   * Inscrever para mudanças de estado
   */
  subscribe(listener: (state: VideoConferenceState) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  /**
   * Notificar listeners sobre mudanças
   */
  private notifyListeners(): void {
    this.listeners.forEach(listener => listener(this.getState()));
  }

  /**
   * Simular conexão (será substituído por Jitsi SDK real)
   */
  private async simulateConnection(): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 500));
  }

  /**
   * Simular desconexão
   */
  private async simulateDisconnection(): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 300));
  }

  /**
   * Simular toggle de áudio
   */
  private async simulateAudioToggle(muted: boolean): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 200));
  }

  /**
   * Simular toggle de vídeo
   */
  private async simulateVideoToggle(muted: boolean): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 200));
  }

  /**
   * Obter URL de configuração do Jitsi Meet
   */
  getJitsiUrl(): string {
    if (!this.config) {
      throw new Error('Serviço não inicializado');
    }

    const baseUrl = this.config.serverURL || 'https://meet.jit.si';
    const params = new URLSearchParams({
      'userInfo.displayName': this.config.displayName,
      'config.startAudioMuted': this.config.audioMuted ? '0' : '1',
      'config.startVideoMuted': this.config.videoMuted ? '0' : '1',
    });

    return `${baseUrl}/${this.config.roomId}?${params.toString()}`;
  }
}

// Singleton instance
let instance: VideoConferenceService | null = null;

export function getVideoConferenceService(): VideoConferenceService {
  if (!instance) {
    instance = new VideoConferenceService();
  }
  return instance;
}
