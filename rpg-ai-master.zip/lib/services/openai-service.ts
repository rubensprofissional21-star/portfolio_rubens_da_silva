/**
 * OpenAI Service - Integração com API real da OpenAI
 * Gera narrativas dinâmicas, NPCs, quests e respostas adaptativas
 */

import { NPC, Quest, Reward, Difficulty } from '@/lib/domain/types';

interface OpenAIMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

class OpenAIService {
  private apiKey: string;
  private model = 'gpt-3.5-turbo';
  private baseUrl = 'https://api.openai.com/v1';
  private conversationHistory: OpenAIMessage[] = [];

  constructor(apiKey: string) {
    this.apiKey = apiKey;
    this.initializeSystemPrompt();
  }

  private initializeSystemPrompt() {
    this.conversationHistory = [
      {
        role: 'system',
        content: `Você é um Mestre de Dungeons & Dragons experiente e criativo. Sua função é:
1. Contar histórias épicas e imersivas
2. Criar NPCs com personalidades únicas e memoráveis
3. Gerar quests desafiadoras e recompensadoras
4. Adaptar a narrativa baseado nas ações dos jogadores
5. Manter o tom narrativo e dramático
6. Usar descrições visuais e emocionais

Sempre responda em português brasileiro, com entusiasmo e criatividade.
Mantenha as respostas concisas mas impactantes (máximo 3-4 parágrafos).`,
      },
    ];
  }

  async generateInitialNarrative(theme: string, difficulty: string): Promise<string> {
    const prompt = `Crie uma narrativa inicial épica para uma sessão de RPG com os seguintes parâmetros:
- Tema: ${theme}
- Dificuldade: ${difficulty}

A narrativa deve:
1. Estabelecer o cenário e atmosfera
2. Introduzir um conflito ou mistério
3. Incentivar os jogadores a agir
4. Ter 2-3 parágrafos no máximo

Responda apenas com a narrativa, sem explicações adicionais.`;

    return this.callOpenAI(prompt);
  }

  async generateNPCs(theme: string, count: number = 2): Promise<NPC[]> {
    const prompt = `Crie ${count} NPCs únicos e memoráveis para um cenário ${theme} de RPG.

Para cada NPC, forneça em formato JSON:
{
  "npcs": [
    {
      "name": "Nome",
      "personality": "Descrição breve da personalidade",
      "backstory": "História de fundo (1-2 frases)",
      "currentMood": "Humor atual"
    }
  ]
}

Responda apenas com o JSON, sem explicações adicionais.`;

    try {
      const response = await this.callOpenAI(prompt);
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        return parsed.npcs.map((npc: any) => ({
          id: `npc_${Date.now()}_${Math.random()}`,
          name: npc.name,
          personality: npc.personality,
          backstory: npc.backstory,
          currentMood: npc.currentMood,
          relationships: {},
        }));
      }
    } catch (error) {
      console.error('Erro ao parsear NPCs:', error);
    }

    return this.generateFallbackNPCs(theme, count);
  }

  async generateQuest(theme: string, difficulty: string): Promise<Quest> {
    const prompt = `Crie uma quest desafiadoras para um cenário ${theme} com dificuldade ${difficulty}.

Forneça em formato JSON:
{
  "quest": {
    "title": "Título da Quest",
    "description": "Descrição detalhada do objetivo",
    "objectives": ["Objetivo 1", "Objetivo 2", "Objetivo 3"],
    "rewards": [
      {"type": "experience", "amount": 100},
      {"type": "gold", "amount": 500},
      {"type": "item", "amount": 1}
    ]
  }
}

Responda apenas com o JSON, sem explicações adicionais.`;

    try {
      const response = await this.callOpenAI(prompt);
      const jsonMatch = response.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        const parsed = JSON.parse(jsonMatch[0]);
        const q = parsed.quest;
        return {
          id: `quest_${Date.now()}`,
          title: q.title,
          description: q.description,
          objectives: q.objectives,
          status: 'active' as const,
          progress: 0,
          difficulty: (difficulty as Difficulty) || 'normal',
          rewards: q.rewards.map((r: any) => ({
            type: r.type,
            amount: r.amount,
          })),
        };
      }
    } catch (error) {
      console.error('Erro ao parsear quest:', error);
    }

    return this.generateFallbackQuest(theme, difficulty);
  }

  async respondToPlayerAction(action: string, context: string): Promise<string> {
    const userMessage = `Contexto da sessão: ${context}

Ação do jogador: ${action}

Responda como o Mestre de RPG, descrevendo o resultado da ação e o que acontece a seguir.`;

    this.conversationHistory.push({
      role: 'user',
      content: userMessage,
    });

    const response = await this.callOpenAI(userMessage, true);

    this.conversationHistory.push({
      role: 'assistant',
      content: response,
    });

    return response;
  }

  async generateDynamicEvent(theme: string, narrativeContext: string): Promise<string> {
    const prompt = `Baseado no contexto narrativo: "${narrativeContext}"

Gere um evento dinâmico e inesperado para um cenário ${theme} que:
1. Complique a situação atual
2. Crie novas oportunidades ou desafios
3. Seja memorável e impactante

Responda com 1-2 parágrafos descrevendo o evento.`;

    return this.callOpenAI(prompt);
  }

  private async callOpenAI(prompt: string, useHistory: boolean = false): Promise<string> {
    try {
      const messages = useHistory
        ? this.conversationHistory
        : [
            {
              role: 'system' as const,
              content: this.conversationHistory[0].content,
            },
            {
              role: 'user' as const,
              content: prompt,
            },
          ];

      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          messages,
          temperature: 0.8,
          max_tokens: 500,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        console.error('OpenAI API Error:', error);
        throw new Error(`OpenAI API Error: ${error.error?.message || 'Unknown error'}`);
      }

      const data = await response.json();
      return data.choices[0]?.message?.content || 'Erro ao gerar resposta';
    } catch (error) {
      console.error('Erro ao chamar OpenAI:', error);
      throw error;
    }
  }

  private generateFallbackNPCs(theme: string, count: number): NPC[] {
    const npcs: NPC[] = [];
    const themes: Record<string, any> = {
      medieval: [
        {
          name: 'Aldric, o Ferreiro',
          personality: 'Gruff mas honesto',
          backstory: 'Forjou armas para reis',
          currentMood: 'Pensativo',
        },
        {
          name: 'Elara, a Maga',
          personality: 'Misteriosa e sábia',
          backstory: 'Estuda magia antiga',
          currentMood: 'Intrigada',
        },
      ],
      scifi: [
        {
          name: 'Commander Vex',
          personality: 'Estrategista brilhante',
          backstory: 'Veterano de 20 guerras',
          currentMood: 'Determinado',
        },
        {
          name: 'Dr. Zara',
          personality: 'Curiosa e inovadora',
          backstory: 'Descobriu nova tecnologia',
          currentMood: 'Entusiasmada',
        },
      ],
    };

    const selectedTheme = themes[theme] || themes.medieval;
    for (let i = 0; i < Math.min(count, selectedTheme.length); i++) {
      const npc = selectedTheme[i];
      npcs.push({
        id: `npc_${Date.now()}_${i}`,
        name: npc.name,
        personality: npc.personality,
        backstory: npc.backstory,
        currentMood: npc.currentMood,
        relationships: {},
      });
    }

    return npcs;
  }

  private generateFallbackQuest(theme: string, difficulty: string): Quest {
    const rewards: Reward[] = [
      { type: 'experience', amount: difficulty === 'hard' ? 500 : 250 },
      { type: 'gold', amount: difficulty === 'hard' ? 1000 : 500 },
      { type: 'item', amount: 1 },
    ];

    return {
      id: `quest_${Date.now()}`,
      title: `Missão do ${theme}`,
      description: 'Uma quest importante aguarda sua ação',
      objectives: ['Investigar', 'Confrontar', 'Resolver'],
      status: 'active' as const,
      progress: 0,
      difficulty: (difficulty as Difficulty) || 'normal',
      rewards,
    };
  }

  resetConversation() {
    this.initializeSystemPrompt();
  }
}

export default OpenAIService;
