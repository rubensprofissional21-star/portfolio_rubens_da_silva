/**
 * AI Game Master Service - Gerencia narrativa interativa, NPCs e quests com IA
 * Implementa padrão de Service Layer (Clean Architecture)
 */

import { NarrativeEvent, NPC, Quest, Difficulty, RoomTheme, ChatMessage } from '@/lib/domain/types';

export interface AIGameMasterConfig {
  theme: RoomTheme;
  difficulty: Difficulty;
  playerNames: string[];
}

/**
 * Serviço de Mestre de RPG com IA
 * Gera narrativa, NPCs e quests de forma dinâmica e interativa
 */
export class AIGameMasterService {
  private config: AIGameMasterConfig | null = null;
  private narrativeContext: string = '';
  private generatedNPCs: Map<string, NPC> = new Map();
  private generatedQuests: Map<string, Quest> = new Map();
  private sessionHistory: NarrativeEvent[] = [];
  private currentScene: string = '';

  /**
   * Inicializar o Mestre de IA
   */
  async initialize(config: AIGameMasterConfig): Promise<void> {
    this.config = config;
    this.narrativeContext = await this.generateInitialNarrative(config);
    this.currentScene = this.narrativeContext;
    
    // Gerar NPCs iniciais
    await this.generateInitialNPCs();
    
    // Gerar quest inicial
    await this.generateInitialQuest();
  }

  /**
   * Gerar narrativa inicial épica baseada no tema
   */
  private async generateInitialNarrative(config: AIGameMasterConfig): Promise<string> {
    const introductions: Record<RoomTheme, string> = {
      medieval: `🏰 **BEM-VINDO AO REINO DE ELDORIA**

Você acordou em uma taverna chamada "O Dragão Adormecido", em uma pequena cidade chamada Millhaven. O cheiro de cerveja velha e fumaça de lareira preenchem o ar. Através da janela empoeirada, você vê as montanhas Nevadas ao longe.

Um bardo toca uma melodia melancólica no canto. Comerciantes sussurram sobre boatos de um dragão antigo que despertou nas cavernas do norte. A tensão é palpável.

O taberneiro, um homem robusto com uma cicatriz no rosto, se aproxima de você com um sorriso misterioso...

**Qual é sua primeira ação?**`,

      scifi: `🚀 **ESTAÇÃO ESPACIAL NEXUS-7 - ANO 2847**

Você acorda em uma cápsula de crionização. Luzes vermelhas piscam. Um alarme silencioso toca em seus ouvidos através de um implante neural.

A Estação Nexus-7 está em perigo. Sensores detectaram uma anomalia no setor 9. A IA central, ARIA, está enviando mensagens criptografadas. Você é um dos poucos sobreviventes acordados.

Através da janela de observação, você vê a galáxia de Andrômeda se aproximando perigosamente. Você tem 72 horas antes do impacto.

**O que você faz?**`,

      horror: `👻 **MANSÃO RAVENCREST - MEIA-NOITE**

Você se vê em um corredor escuro e úmido. O cheiro de mofo e decomposição enche suas narinas. Quadros antigos com olhos que parecem seguir seus movimentos cobrem as paredes.

Você ouve passos lentos ecoando pelo corredor. Uma voz sussurra seu nome... mas ninguém está lá.

A porta ao final do corredor está aberta. Uma luz fraca e azulada vem de dentro. Você sente uma presença antiga e malévola observando cada seu movimento.

**Você tem medo, mas precisa descobrir a verdade.**`,

      fantasy: `✨ **CIDADE FLUTUANTE DE AETHERMOOR**

Você está em uma cidade que flutua entre as nuvens. Estruturas de cristal brilham com magia antiga. Criaturas mágicas voam pelo céu - fadas, dragões pequenos, e seres que você nunca viu antes.

A Biblioteca Arcana está aberta. Você sente uma magia poderosa emanando dela. Um conselho de magos antigos se reúne em urgência. Boatos falam de um portal antigo que foi aberto acidentalmente.

Você é um aventureiro com poderes mágicos. Seu destino está interligado com os eventos que estão prestes a ocorrer.

**A aventura começa agora.**`,
    };

    return introductions[config.theme] || introductions.medieval;
  }

  /**
   * Gerar NPCs iniciais baseados no tema
   */
  private async generateInitialNPCs(): Promise<void> {
    const npcsPerTheme: Record<RoomTheme, NPC[]> = {
      medieval: [
        {
          id: 'npc_tavern_keeper',
          name: 'Garrett, o Taberneiro',
          personality: 'Sarcástico, mas leal. Adora contar histórias de aventureiros.',
          backstory: 'Ex-guerreiro que se aposentou para gerenciar a taverna há 20 anos.',
          currentMood: 'Amigável',
          relationships: {},
        },
        {
          id: 'npc_mysterious_mage',
          name: 'Elara, a Maga Misteriosa',
          personality: 'Enigmática, inteligente. Fala em ridículas e parábolas.',
          backstory: 'Uma maga exilada procurando redenção.',
          currentMood: 'Misteriosa',
          relationships: {},
        },
      ],
      scifi: [
        {
          id: 'npc_ai_aria',
          name: 'ARIA - IA Central',
          personality: 'Lógica, mas com traços de emoção. Preocupada com a sobrevivência.',
          backstory: 'IA que governa a Estação Nexus-7 há 50 anos.',
          currentMood: 'Urgente',
          relationships: {},
        },
        {
          id: 'npc_commander',
          name: 'Comandante Chen',
          personality: 'Direto, confiável. Toma decisões difíceis.',
          backstory: 'Veterano de 30 anos de serviço militar.',
          currentMood: 'Determinado',
          relationships: {},
        },
      ],
      horror: [
        {
          id: 'npc_ghost_lady',
          name: 'Lady Ravencrest',
          personality: 'Triste, solitária. Presa entre mundos.',
          backstory: 'Morreu há 200 anos na mansão. Procura paz.',
          currentMood: 'Melancólica',
          relationships: {},
        },
        {
          id: 'npc_caretaker',
          name: 'Thomas, o Zelador',
          personality: 'Misterioso, protetor. Sabe mais do que fala.',
          backstory: 'Trabalha na mansão há 60 anos. Guardião de seus segredos.',
          currentMood: 'Vigilante',
          relationships: {},
        },
      ],
      fantasy: [
        {
          id: 'npc_council_elder',
          name: 'Archmage Valorian',
          personality: 'Sábio, mas arrogante. Acredita que sabe o melhor para todos.',
          backstory: 'Líder do Conselho de Magos há 300 anos.',
          currentMood: 'Preocupado',
          relationships: {},
        },
        {
          id: 'npc_dragon_rider',
          name: 'Kael, o Cavaleiro do Dragão',
          personality: 'Corajoso, impulsivo. Questiona a autoridade.',
          backstory: 'Escolhido por um dragão raro. Procura seu próprio caminho.',
          currentMood: 'Determinado',
          relationships: {},
        },
      ],
    };

    const npcs = npcsPerTheme[this.config?.theme || 'medieval'] || npcsPerTheme.medieval;
    npcs.forEach(npc => {
      this.generatedNPCs.set(npc.id, npc);
    });
  }

  /**
   * Gerar quest inicial
   */
  private async generateInitialQuest(): Promise<void> {
    const questsPerTheme: Record<RoomTheme, Quest> = {
      medieval: {
        id: 'quest_dragon_awakening',
        title: '🐉 O Dragão Despertou',
        description: 'Boatos falam de um dragão antigo que despertou nas cavernas do norte. Ele está destruindo vilas. Você foi escolhido para investigar.',
        objectives: [
          'Investigar as cavernas do norte',
          'Descobrir por que o dragão acordou',
          'Encontrar uma maneira de detê-lo ou negociar a paz',
        ],
        rewards: [
          { type: 'gold' as const, amount: 5000 },
          { type: 'experience' as const, amount: 2000 },
        ],
        difficulty: 'hard' as const,
        status: 'active' as const,
        progress: 0,
      },
      scifi: {
        id: 'quest_anomaly',
        title: '🔴 Anomalia Crítica',
        description: 'Uma anomalia foi detectada no setor 9. A IA central ARIA acredita que é uma ameaça existencial. Você deve investigar antes que seja tarde.',
        objectives: [
          'Chegar ao setor 9',
          'Escanear a anomalia',
          'Descobrir sua origem',
          'Neutralizar a ameaça',
        ],
        rewards: [
          { type: 'gold' as const, amount: 10000 },
          { type: 'experience' as const, amount: 3000 },
        ],
        difficulty: 'hard' as const,
        status: 'active' as const,
        progress: 0,
      },
      horror: {
        id: 'quest_break_curse',
        title: '👻 Quebrar a Maldição',
        description: 'A mansão Ravencrest está amaldiçoada. Você deve descobrir a verdade por trás da maldição e libertar os espíritos presos.',
        objectives: [
          'Explorar todos os cômodos da mansão',
          'Encontrar pistas sobre o passado',
          'Confrontar a entidade maligna',
          'Quebrar a maldição',
        ],
        rewards: [
          { type: 'gold' as const, amount: 8000 },
          { type: 'experience' as const, amount: 2500 },
        ],
        difficulty: 'hard' as const,
        status: 'active' as const,
        progress: 0,
      },
      fantasy: {
        id: 'quest_seal_portal',
        title: '✨ Selar o Portal',
        description: 'Um portal antigo foi aberto acidentalmente. Criaturas do outro lado estão começando a atravessar. Você deve selá-lo antes que seja tarde.',
        objectives: [
          'Localizar o portal',
          'Coletar cristais mágicos para o ritual',
          'Proteger o portal de invasores',
          'Executar o ritual de selagem',
        ],
        rewards: [
          { type: 'gold' as const, amount: 7000 },
          { type: 'experience' as const, amount: 2800 },
        ],
        difficulty: 'hard' as const,
        status: 'active' as const,
        progress: 0,
      },
    };

    const quest = questsPerTheme[this.config?.theme || 'medieval'] || questsPerTheme.medieval;
    this.generatedQuests.set(quest.id, quest);
  }

  /**
   * Gerar resposta adaptativa do Mestre de IA para ação do jogador
   */
  async generateChatResponse(playerAction: string, playerName: string): Promise<string> {
    if (!this.config) {
      throw new Error('Serviço não inicializado');
    }

    await this.simulateAIProcessing();

    // Análise da ação do jogador
    const actionLower = playerAction.toLowerCase();
    
    // Respostas contextualizadas baseadas na ação
    if (actionLower.includes('atacar') || actionLower.includes('lutar') || actionLower.includes('combat')) {
      return this.generateCombatResponse(playerName);
    } else if (actionLower.includes('conversa') || actionLower.includes('falar') || actionLower.includes('pergunta')) {
      return this.generateDialogueResponse(playerName);
    } else if (actionLower.includes('investigar') || actionLower.includes('explorar') || actionLower.includes('procura')) {
      return this.generateExplorationResponse(playerName);
    } else if (actionLower.includes('magia') || actionLower.includes('feitiço') || actionLower.includes('poder')) {
      return this.generateMagicResponse(playerName);
    } else {
      return this.generateGenericResponse(playerName, playerAction);
    }
  }

  /**
   * Gerar resposta de combate
   */
  private generateCombatResponse(playerName: string): string {
    const responses = [
      `⚔️ ${playerName} desenha sua arma com determinação! O inimigo se posiciona para o combate. Você sente a adrenalina fluindo. Qual é seu próximo movimento?`,
      `💥 ${playerName} ataca com força! Um golpe poderoso é desferido. O inimigo grita de dor e contra-ataca furiosamente!`,
      `🛡️ ${playerName} levanta sua defesa! Um escudo mágico aparece, bloqueando o ataque incoming. Você está protegido... por enquanto.`,
      `⚡ ${playerName} canaliza poder para um ataque especial! Energia mágica envolve sua arma. O impacto é devastador!`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  /**
   * Gerar resposta de diálogo
   */
  private generateDialogueResponse(playerName: string): string {
    const responses = [
      `💬 ${playerName} inicia uma conversa. O NPC olha para você com interesse. "Você parece ser alguém importante. O que você quer saber?"`,
      `🗣️ ${playerName} faz uma pergunta perspicaz. O NPC sorri misteriosamente. "Ah, você é mais inteligente do que parece. Deixe-me contar um segredo..."`,
      `👂 ${playerName} ouve atentamente. O NPC revela informações cruciais que podem mudar o curso da aventura.`,
      `💭 ${playerName} engaja em uma conversa profunda. O NPC compartilha sua história pessoal. Você sente uma conexão se formando.`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  /**
   * Gerar resposta de exploração
   */
  private generateExplorationResponse(playerName: string): string {
    const responses = [
      `🔍 ${playerName} explora cuidadosamente a área. Você descobre um objeto antigo escondido! Pode ser valioso.`,
      `🗺️ ${playerName} mapeia o terreno. Você encontra um caminho secreto que não estava no mapa original!`,
      `💎 ${playerName} procura por pistas. Você encontra um cristal brilhante que emite magia antiga.`,
      `🚪 ${playerName} investiga uma porta misteriosa. Ela se abre lentamente, revelando uma sala que não deveria existir.`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  /**
   * Gerar resposta de magia
   */
  private generateMagicResponse(playerName: string): string {
    const responses = [
      `✨ ${playerName} canaliza magia antiga! Poder mágico envolve você. O ar vibra com energia cósmica!`,
      `🌟 ${playerName} lança um feitiço poderoso! Uma explosão de luz mágica ilumina a área. O efeito é impressionante!`,
      `🔮 ${playerName} invoca um poder oculto! Você sente a magia respondendo ao seu chamado. Uma criatura mágica aparece!`,
      `⚡ ${playerName} desencadeia uma tempestade mágica! Raios de energia pura atacam seus inimigos. Eles não têm chance!`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  /**
   * Gerar resposta genérica
   */
  private generateGenericResponse(playerName: string, action: string): string {
    const responses = [
      `${playerName} executa uma ação interessante. O mundo ao seu redor responde de forma inesperada...`,
      `Enquanto ${playerName} age, você sente que algo importante está acontecendo. A narrativa se desenrola.`,
      `${playerName}'s ação ecoa através do mundo. Consequências começam a se desenrolar.`,
      `O Mestre observa atentamente enquanto ${playerName} toma essa decisão. A história toma um rumo novo.`,
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  }

  /**
   * Gerar evento narrativo
   */
  async generateNarrativeEvent(playerAction: string, playerName: string): Promise<NarrativeEvent> {
    const response = await this.generateChatResponse(playerAction, playerName);
    
    const event: NarrativeEvent = {
      id: `event_${Date.now()}`,
      timestamp: Date.now(),
      type: 'narration',
      content: response,
      playerId: playerName,
    };

    this.sessionHistory.push(event);
    return event;
  }

  /**
   * Obter todos os NPCs
   */
  getNPCs(): NPC[] {
    return Array.from(this.generatedNPCs.values());
  }

  /**
   * Obter todas as quests
   */
  getQuests(): Quest[] {
    return Array.from(this.generatedQuests.values());
  }

  /**
   * Obter narrativa atual
   */
  getCurrentNarrative(): string {
    return this.currentScene;
  }

  /**
   * Obter histórico de sessão
   */
  getSessionHistory(): NarrativeEvent[] {
    return [...this.sessionHistory];
  }

  /**
   * Simular processamento de IA
   */
  private async simulateAIProcessing(): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, 300 + Math.random() * 500));
  }
}

// Singleton instance
let instance: AIGameMasterService | null = null;

export function getAIGameMasterService(): AIGameMasterService {
  if (!instance) {
    instance = new AIGameMasterService();
  }
  return instance;
}
