/**
 * Domain Types - Entidades principais do aplicativo
 * Seguindo Clean Architecture: tipos de negócio independentes de framework
 */

export type RoomTheme = 'medieval' | 'scifi' | 'horror' | 'fantasy';
export type Difficulty = 'easy' | 'normal' | 'hard';
export type ItemRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';
export type NarrativeEventType = 'narration' | 'npc_action' | 'player_action' | 'quest_update' | 'event';

/**
 * Sala de RPG
 */
export interface Room {
  id: string;
  name: string;
  theme: RoomTheme;
  difficulty: Difficulty;
  maxPlayers: number;
  currentPlayers: Player[];
  createdAt: number;
  narrativeHistory: NarrativeEvent[];
  status: 'waiting' | 'in_progress' | 'completed';
}

/**
 * Jogador
 */
export interface Player {
  id: string;
  nickname: string;
  character: Character;
  joinedAt: number;
  isHost: boolean;
}

/**
 * Personagem do jogador
 */
export interface Character {
  id: string;
  name: string;
  class: string;
  level: number;
  experience: number;
  attributes: Attributes;
  inventory: Item[];
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
}

/**
 * Atributos do personagem
 */
export interface Attributes {
  strength: number;
  intelligence: number;
  dexterity: number;
  constitution: number;
  wisdom: number;
  charisma: number;
}

/**
 * Item do inventário
 */
export interface Item {
  id: string;
  name: string;
  description: string;
  rarity: ItemRarity;
  type: string;
  quantity: number;
}

/**
 * Evento narrativo
 */
export interface NarrativeEvent {
  id: string;
  timestamp: number;
  type: NarrativeEventType;
  content: string;
  npc?: NPC;
  quest?: Quest;
  playerId?: string;
  playerAction?: string;
}

/**
 * NPC (Personagem não-jogador)
 */
export interface NPC {
  id: string;
  name: string;
  personality: string;
  backstory: string;
  currentMood: string;
  relationships: Record<string, string>;
  lastAction?: string;
}

/**
 * Quest/Missão
 */
export interface Quest {
  id: string;
  title: string;
  description: string;
  objectives: string[];
  rewards: Reward[];
  status: 'active' | 'completed' | 'failed';
  progress: number;
  difficulty: Difficulty;
}

/**
 * Recompensa de quest
 */
export interface Reward {
  type: 'experience' | 'gold' | 'item';
  amount: number;
  item?: Item;
}

/**
 * Mensagem de chat
 */
export interface ChatMessage {
  id: string;
  sender: 'player' | 'master';
  senderName: string;
  content: string;
  timestamp: number;
  type: 'text' | 'action' | 'system';
}

/**
 * Ação rápida disponível para o jogador
 */
export interface QuickAction {
  id: string;
  label: string;
  description: string;
  icon: string;
  action: string;
  enabled: boolean;
}

/**
 * Estado da sessão
 */
export interface SessionState {
  roomId: string;
  playerId: string;
  room: Room;
  player: Player;
  narrativeHistory: NarrativeEvent[];
  chatHistory: ChatMessage[];
  quests: Quest[];
  npcs: NPC[];
  quickActions: QuickAction[];
  isConnected: boolean;
  isMasterResponding: boolean;
}

/**
 * Configurações do app
 */
export interface AppSettings {
  nickname: string;
  theme: 'light' | 'dark' | 'auto';
  audioEnabled: boolean;
  videoEnabled: boolean;
  hapticEnabled: boolean;
  recentRooms: string[];
}
