# RPG AI Master

**Plataforma de RPG de Mesa Online com Mestre de IA Generativa**

![RPG AI Master](https://d2xsxph8kpxj0f.cloudfront.net/310519663627943951/G3cBwWh7xPbLZW5Tih8a2p/icon-WUbFE8t35UYLPBvEF79fwU.webp)

---

## 📋 Visão Geral

RPG AI Master é uma plataforma inovadora que combina a experiência clássica de RPG de mesa com tecnologias modernas de inteligência artificial e videoconferência. O diferencial principal é a presença de um **Mestre de RPG controlado por IA generativa**, que conduz a narrativa em tempo real, adaptando-se às ações dos jogadores e criando uma experiência imersiva e dinâmica.

### Problema Resolvido

Jogadores de RPG enfrentam desafios ao tentar se reunir presencialmente, especialmente em contextos remotos ou com horários incompatíveis. Além disso, a falta de um Mestre experiente pode limitar a qualidade da narrativa. RPG AI Master resolve esses problemas ao:

- **Eliminar barreiras geográficas**: Videoconferência integrada permite que jogadores se conectem de qualquer lugar
- **Disponibilidade de Mestre**: IA generativa funciona 24/7, sem necessidade de um Mestre humano experiente
- **Narrativa Dinâmica**: Sistema de IA adapta a história em tempo real baseado nas ações dos jogadores
- **Experiência Imersiva**: Interface intuitiva e integrada com chat, vídeo e narrativa em um único aplicativo

---

## 🎮 Funcionalidades Principais

### 1. Autenticação e Gerenciamento de Salas
- Entrada rápida com nickname (sem necessidade de cadastro complexo)
- Criação de salas com temas personalizáveis (Fantasia Medieval, Ficção Científica, Horror, etc.)
- Seleção de dificuldade (Fácil, Normal, Difícil)
- Entrada em salas existentes via código único
- Histórico de sessões recentes

### 2. Integração com Videoconferência
- Embed do **Jitsi Meet** para videoconferência sem necessidade de contas externas
- Controles de áudio e vídeo integrados
- Indicador de participantes conectados
- Suporte para múltiplos jogadores simultâneos

### 3. Mestre de RPG com IA (Core)
- **Geração de Narrativa em Tempo Real**: IA generativa cria descrições imersivas do cenário
- **NPCs Dinâmicos**: Personagens não-jogadores com personalidade, histórico e relacionamentos
- **Quests Adaptativas**: Missões geradas dinamicamente baseadas no tema e dificuldade
- **Eventos Dinâmicos**: Acontecimentos inesperados que modificam o curso da história
- **Adaptação de História**: A narrativa se ajusta às ações e decisões dos jogadores

### 4. Interface de Jogo Integrada
- **Abas Navegáveis**: Narrativa, Chat, Personagem, Quests, Videoconferência
- **Chat em Tempo Real**: Interação direta com o Mestre de IA
- **Visualização de Narrativa**: Histórico completo de eventos e descrições
- **Ficha de Personagem**: Atributos, inventário, saúde, mana
- **Sistema de Quests**: Acompanhamento de objetivos e progresso

### 5. Persistência de Sessão
- Armazenamento local de estado da sessão
- Possibilidade de retomar sessões interrompidas
- Histórico de sessões completadas
- Configurações do jogador sincronizadas

---

## 🛠️ Tecnologias Utilizadas

| Categoria | Tecnologia | Versão | Propósito |
|-----------|-----------|--------|----------|
| **Framework** | React Native | 0.81 | Desenvolvimento mobile cross-platform |
| **Runtime** | Expo | 54 | Execução e build do app |
| **Linguagem** | TypeScript | 5.9 | Type-safety e melhor DX |
| **Roteamento** | Expo Router | 6 | Navegação entre telas |
| **Styling** | NativeWind (Tailwind) | 4 | Estilização com Tailwind CSS |
| **Estado** | React Context + useReducer | - | Gerenciamento de estado global |
| **Armazenamento** | AsyncStorage | 2.2 | Persistência local de dados |
| **API** | tRPC | 11.7 | Comunicação com servidor (opcional) |
| **Videoconferência** | Jitsi Meet SDK | - | Integração de vídeo/áudio |
| **IA** | OpenAI API (integrável) | - | Geração de narrativa e NPCs |
| **Animações** | React Native Reanimated | 4 | Animações suaves e performáticas |
| **Ícones** | Expo Vector Icons | 15 | Ícones e símbolos |

---

## 📱 Arquitetura do Projeto

O projeto segue os princípios de **Clean Architecture** e **MVVM**, garantindo código escalável, testável e fácil de manter.

```
rpg-ai-master/
├── app/                           # Telas e roteamento (Expo Router)
│   ├── (tabs)/                   # Telas com tab bar
│   │   └── index.tsx             # Home screen
│   ├── _layout.tsx               # Root layout com providers
│   ├── splash.tsx                # Splash screen
│   ├── create-room.tsx           # Criação de sala
│   ├── join-room.tsx             # Entrada em sala
│   ├── settings.tsx              # Configurações
│   ├── game.tsx                  # Tela de jogo (versão básica)
│   └── game-integrated.tsx       # Tela de jogo (versão integrada)
│
├── components/                    # Componentes reutilizáveis
│   ├── screen-container.tsx      # Wrapper com SafeArea
│   ├── videoconference-view.tsx  # Componente de videoconferência
│   └── ui/                       # Componentes de UI
│       ├── button.tsx            # Botão customizado
│       ├── text-input.tsx        # Input de texto
│       └── icon-symbol.tsx       # Mapeamento de ícones
│
├── hooks/                         # Custom hooks
│   ├── use-colors.ts             # Tema de cores
│   ├── use-color-scheme.ts       # Detecção de tema
│   ├── use-player-settings.ts    # Configurações do jogador
│   ├── use-videoconference.ts    # Gerenciamento de videoconferência
│   └── use-ai-game-master.ts     # Gerenciamento de IA
│
├── lib/                           # Lógica de negócio (Domain Layer)
│   ├── domain/
│   │   └── types.ts              # Tipos e interfaces principais
│   ├── services/
│   │   ├── videoconference-service.ts  # Serviço de videoconferência
│   │   └── ai-game-master-service.ts   # Serviço de IA
│   ├── context/
│   │   └── game-context.tsx      # Context global de jogo
│   ├── utils.ts                  # Funções utilitárias
│   └── trpc.ts                   # Cliente tRPC
│
├── assets/                        # Imagens e recursos
│   └── images/
│       ├── icon.png              # Logo do app
│       ├── splash-icon.png       # Ícone de splash
│       └── favicon.png           # Favicon
│
├── app.config.ts                 # Configuração Expo
├── tailwind.config.js            # Configuração Tailwind
├── theme.config.js               # Tokens de tema
├── package.json                  # Dependências
├── tsconfig.json                 # Configuração TypeScript
├── design.md                     # Documentação de design
├── todo.md                       # Rastreamento de tarefas
└── README.md                     # Este arquivo
```

---

## 🚀 Como Começar

### Pré-requisitos

Certifique-se de ter instalado em seu sistema:

- **Node.js** 18+ ([Download](https://nodejs.org/))
- **npm** ou **pnpm** (gerenciador de pacotes)
- **Expo CLI** (opcional, mas recomendado)

```bash
npm install -g expo-cli
```

### Instalação Passo a Passo

#### 1. Clonar o Repositório

```bash
git clone https://github.com/seu-usuario/rpg-ai-master.git
cd rpg-ai-master
```

#### 2. Instalar Dependências

```bash
pnpm install
# ou
npm install
```

#### 3. Configurar Variáveis de Ambiente (Opcional)

Se você deseja integrar com uma API de IA real (como OpenAI), crie um arquivo `.env.local`:

```env
EXPO_PUBLIC_OPENAI_API_KEY=sua_chave_aqui
EXPO_PUBLIC_JITSI_SERVER_URL=https://meet.jit.si
```

#### 4. Iniciar o Servidor de Desenvolvimento

```bash
pnpm dev
# ou
npm run dev
```

O aplicativo estará disponível em:
- **Web**: http://localhost:8081
- **QR Code para Expo Go**: Escaneie o código exibido no terminal

### Executar em Dispositivos

#### iOS (Mac apenas)
```bash
pnpm ios
```

#### Android
```bash
pnpm android
```

#### Web
```bash
pnpm dev:metro
```

---

## 📖 Guia de Uso

### Criando uma Sala

1. Abra o aplicativo e toque em **"🎭 Criar Nova Sala"**
2. Preencha os dados:
   - **Nome da Sala**: Ex: "A Taverna do Dragão"
   - **Tema**: Escolha entre Fantasia Medieval, Ficção Científica, Horror ou Fantasia
   - **Dificuldade**: Fácil, Normal ou Difícil
   - **Máximo de Jogadores**: 2-10
3. Toque em **"Criar Sala"**
4. Você será redirecionado para a tela de jogo

### Entrando em uma Sala Existente

1. Toque em **"🚪 Entrar em Sala"**
2. Insira o **Código da Sala** (fornecido pelo anfitrião)
3. Insira seu **Nickname**
4. Toque em **"Entrar na Sala"**

### Interagindo com o Mestre de IA

1. Na tela de jogo, navegue até a aba **"💬 Chat"**
2. Digite sua ação ou pergunta no campo de entrada
3. Toque em **"→"** para enviar
4. O Mestre de IA responderá em tempo real, adaptando a narrativa

### Acompanhando a Narrativa

1. Navegue até a aba **"📖 Narrativa"**
2. Veja o histórico completo de eventos, ações e descrições
3. Scroll para cima para ver eventos anteriores

### Gerenciando Seu Personagem

1. Navegue até a aba **"👤 Personagem"**
2. Visualize seus atributos (Força, Inteligência, Destreza, etc.)
3. Acompanhe sua saúde, mana e inventário

### Acompanhando Quests

1. Navegue até a aba **"⚔️ Quests"**
2. Veja a lista de missões ativas
3. Acompanhe o progresso de cada quest

---

## 🔧 Configuração Avançada

### Integração com OpenAI

Para usar a IA generativa da OpenAI em vez da simulação:

1. Obtenha uma chave de API em [https://platform.openai.com/api-keys](https://platform.openai.com/api-keys)
2. Adicione à `.env.local`:
   ```env
   EXPO_PUBLIC_OPENAI_API_KEY=sk-...
   ```
3. Modifique `lib/services/ai-game-master-service.ts` para usar a API real

### Customizar Temas de Cores

Edite `theme.config.js` para alterar a paleta de cores:

```javascript
const themeColors = {
  primary: { light: '#8B6914', dark: '#D4AF37' },
  background: { light: '#FFFFFF', dark: '#0F0F0F' },
  // ... mais cores
};
```

### Adicionar Novos Temas de Aventura

Modifique `lib/services/ai-game-master-service.ts`:

```typescript
const themeDescriptions: Record<RoomTheme, string> = {
  medieval: '...',
  scifi: '...',
  horror: '...',
  fantasy: '...',
  // Adicione novo tema aqui
  cyberpunk: 'Uma metrópole futurista com neon...',
};
```

---

## 🧪 Testes

O projeto inclui suporte para testes com **Vitest**:

```bash
# Executar testes
pnpm test

# Modo watch
pnpm test --watch

# Cobertura
pnpm test --coverage
```

---

## 📦 Build e Distribuição

### Build para Web

```bash
pnpm build
```

Saída em: `dist/`

### Build para iOS (requer Mac)

```bash
eas build --platform ios
```

### Build para Android

```bash
eas build --platform android
```

### Gerar APK Local (Android)

```bash
eas build --platform android --local
```

---

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| **Erro: "Metro bundler failed"** | Limpe o cache: `pnpm start --reset-cache` |
| **Videoconferência não funciona** | Verifique permissões de câmera/microfone no dispositivo |
| **IA não responde** | Verifique conexão de internet e chave de API (se usada) |
| **Tela branca no web** | Abra DevTools (F12) e verifique console para erros |
| **AsyncStorage vazio** | Dados são perdidos ao desinstalar; use backend para persistência |

---

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Faça um fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

---

## 📝 Roadmap

- [ ] **Fase 1**: Autenticação e gerenciamento de salas ✅
- [ ] **Fase 2**: Integração com Jitsi Meet ✅
- [ ] **Fase 3**: Mestre de IA com narrativa ✅
- [ ] **Fase 4**: Interface de jogo completa (em progresso)
- [ ] **Fase 5**: Sistema de sessão e persistência (em progresso)
- [ ] **Fase 6**: Assets visuais e branding ✅
- [ ] **Fase 7**: Documentação e QR Code ✅
- [ ] **Fase 8**: Testes e otimização (próximo)
- [ ] Integração com banco de dados real (PostgreSQL)
- [ ] Sistema de autenticação com OAuth
- [ ] Histórico de sessões na nuvem
- [ ] Customização avançada de personagens
- [ ] Sistema de efeitos sonoros e música
- [ ] Suporte a múltiplos idiomas
- [ ] Modo offline com sincronização
- [ ] Análise de dados de sessões

---

## 📄 Licença

Este projeto está licenciado sob a **MIT License** - veja o arquivo [LICENSE](LICENSE) para detalhes.

---

## 👥 Autores

- **Desenvolvido por**: Manus AI
- **Conceito Original**: Plataforma de RPG com IA Generativa
- **Data de Criação**: Maio de 2026

---

## 💬 Suporte

Para suporte, abra uma issue no repositório ou entre em contato através de:

- **Email**: support@rpgaimaster.com
- **Discord**: [Servidor Oficial](https://discord.gg/rpgaimaster)
- **GitHub Issues**: [Reportar Bug](https://github.com/seu-usuario/rpg-ai-master/issues)

---

## 🙏 Agradecimentos

Agradecimentos especiais a:

- **Expo Team** por fornecer um excelente framework para desenvolvimento mobile
- **Jitsi Meet** por disponibilizar SDK de videoconferência open-source
- **OpenAI** por fornecer APIs de IA generativa
- **Comunidade React Native** por suporte e recursos

---

## 📊 Estatísticas do Projeto

| Métrica | Valor |
|---------|-------|
| **Linhas de Código** | ~3,500+ |
| **Componentes** | 15+ |
| **Hooks Customizados** | 5+ |
| **Telas** | 8 |
| **Tipos TypeScript** | 20+ |
| **Dependências** | 40+ |
| **Tempo de Build** | ~2-3 minutos |
| **Tamanho APK** | ~45-50 MB |

---

**Versão**: 1.0.0  
**Última Atualização**: Maio 2026  
**Status**: Em Desenvolvimento Ativo ✨

---

*RPG AI Master - Transformando a forma como você joga RPG de mesa online.*
