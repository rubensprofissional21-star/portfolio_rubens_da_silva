/**
 * Hook useOpenAITRPC - Integração com OpenAI via tRPC
 * Corrigido para usar useMutation corretamente
 */

import { useState } from 'react';
import { trpc } from '@/lib/trpc';
import { type NPC, type Quest } from '@/lib/domain/types';

export function useOpenAITRPC() {
  const [error, setError] = useState<string | null>(null);

  // Mutations
  const generateNarrativeMutation = trpc.openai.generateNarrative.useMutation();
  const generateNPCsMutation = trpc.openai.generateNPCs.useMutation();
  const generateQuestMutation = trpc.openai.generateQuest.useMutation();
  const respondToActionMutation = trpc.openai.respondToAction.useMutation();

  const isLoading =
    generateNarrativeMutation.isPending ||
    generateNPCsMutation.isPending ||
    generateQuestMutation.isPending ||
    respondToActionMutation.isPending;

  /**
   * Gerar narrativa inicial
   */
  const generateNarrative = async (theme: string, difficulty: string): Promise<string> => {
    try {
      setError(null);
      const result = await generateNarrativeMutation.mutateAsync({
        theme,
        difficulty,
      });
      return result.narrative || 'Uma aventura épica começa...';
    } catch (err: any) {
      const errorMsg = err?.message || 'Erro ao gerar narrativa';
      console.error('Erro ao gerar narrativa:', errorMsg);
      setError(errorMsg);
      return 'Uma aventura épica começa... (modo simulado)';
    }
  };

  /**
   * Gerar NPCs
   */
  const generateNPCs = async (theme: string, count: number = 2): Promise<NPC[]> => {
    try {
      setError(null);
      const result = await generateNPCsMutation.mutateAsync({
        theme,
        count,
      });
      return result.npcs || [];
    } catch (err: any) {
      const errorMsg = err?.message || 'Erro ao gerar NPCs';
      console.error('Erro ao gerar NPCs:', errorMsg);
      setError(errorMsg);
      return [];
    }
  };

  /**
   * Gerar quest
   */
  const generateQuest = async (theme: string, difficulty: string): Promise<Quest | null> => {
    try {
      setError(null);
      const result = await generateQuestMutation.mutateAsync({
        theme,
        difficulty,
      });
      return result.quest || null;
    } catch (err: any) {
      const errorMsg = err?.message || 'Erro ao gerar quest';
      console.error('Erro ao gerar quest:', errorMsg);
      setError(errorMsg);
      return null;
    }
  };

  /**
   * Responder à ação do jogador
   */
  const respondToAction = async (action: string, context: string): Promise<string> => {
    try {
      setError(null);
      const result = await respondToActionMutation.mutateAsync({
        action,
        context,
      });
      return result.response || 'O Mestre está pensando...';
    } catch (err: any) {
      const errorMsg = err?.message || 'Erro ao processar ação';
      console.error('Erro ao processar ação:', errorMsg);
      setError(errorMsg);
      return 'O Mestre está pensando... (modo simulado)';
    }
  };

  return {
    generateNarrative,
    generateNPCs,
    generateQuest,
    respondToAction,
    isLoading,
    error,
  };
}
