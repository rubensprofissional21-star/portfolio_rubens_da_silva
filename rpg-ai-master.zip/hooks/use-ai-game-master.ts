/**
 * Hook: useAIGameMaster
 * Gerencia narrativa, NPCs e quests com IA
 */

import { useState, useCallback } from 'react';
import {
  AIGameMasterService,
  AIGameMasterConfig,
  getAIGameMasterService,
} from '@/lib/services/ai-game-master-service';
import { NarrativeEvent, NPC, Quest } from '@/lib/domain/types';

export function useAIGameMaster() {
  const service = getAIGameMasterService();
  const [isInitialized, setIsInitialized] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [npcs, setNPCs] = useState<NPC[]>([]);
  const [quests, setQuests] = useState<Quest[]>([]);

  const initialize = useCallback(
    async (config: AIGameMasterConfig) => {
      try {
        await service.initialize(config);
        setIsInitialized(true);
      } catch (error) {
        console.error('Erro ao inicializar Mestre de IA:', error);
        throw error;
      }
    },
    [service]
  );

  const generateNarrativeEvent = useCallback(
    async (playerAction: string, playerName: string): Promise<NarrativeEvent> => {
      if (!isInitialized) {
        throw new Error('Mestre de IA não inicializado');
      }

      setIsGenerating(true);
      try {
        const event = await service.generateNarrativeEvent(playerAction, playerName);
        return event;
      } catch (error) {
        console.error('Erro ao gerar evento narrativo:', error);
        throw error;
      } finally {
        setIsGenerating(false);
      }
    },
    [service, isInitialized]
  );

  const getNPCs = useCallback(() => {
    if (!isInitialized) {
      return [];
    }
    const allNPCs = service.getNPCs();
    setNPCs(allNPCs);
    return allNPCs;
  }, [service, isInitialized]);

  const getQuests = useCallback(() => {
    if (!isInitialized) {
      return [];
    }
    const allQuests = service.getQuests();
    setQuests(allQuests);
    return allQuests;
  }, [service, isInitialized]);

  const generateChatResponse = useCallback(
    async (message: string, playerName: string): Promise<string> => {
      if (!isInitialized) {
        throw new Error('Mestre de IA não inicializado');
      }

      setIsGenerating(true);
      try {
        const response = await service.generateChatResponse(message, playerName);
        return response;
      } catch (error) {
        console.error('Erro ao gerar resposta de chat:', error);
        throw error;
      } finally {
        setIsGenerating(false);
      }
    },
    [service, isInitialized]
  );

  const getCurrentNarrative = useCallback(() => {
    return service.getCurrentNarrative();
  }, [service]);

  const getSessionHistory = useCallback(() => {
    return service.getSessionHistory();
  }, [service]);

  return {
    isInitialized,
    isGenerating,
    npcs,
    quests,
    initialize,
    generateNarrativeEvent,
    getNPCs,
    getQuests,
    generateChatResponse,
    getCurrentNarrative,
    getSessionHistory,
  };
}
