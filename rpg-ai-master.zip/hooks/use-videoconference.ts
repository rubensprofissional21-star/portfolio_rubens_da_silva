/**
 * Hook: useVideoconference
 * Gerencia estado de videoconferência com Jitsi Meet
 */

import { useState, useEffect, useCallback } from 'react';
import {
  VideoConferenceService,
  VideoConferenceConfig,
  VideoConferenceState,
  getVideoConferenceService,
} from '@/lib/services/videoconference-service';

export function useVideoconference() {
  const service = getVideoConferenceService();
  const [state, setState] = useState<VideoConferenceState>(service.getState());
  const [isInitializing, setIsInitializing] = useState(false);

  // Inscrever para mudanças de estado
  useEffect(() => {
    const unsubscribe = service.subscribe(setState);
    return () => unsubscribe();
  }, [service]);

  const initialize = useCallback(
    async (config: VideoConferenceConfig) => {
      setIsInitializing(true);
      try {
        await service.initialize(config);
      } catch (error) {
        console.error('Erro ao inicializar videoconferência:', error);
        throw error;
      } finally {
        setIsInitializing(false);
      }
    },
    [service]
  );

  const disconnect = useCallback(async () => {
    try {
      await service.disconnect();
    } catch (error) {
      console.error('Erro ao desconectar:', error);
    }
  }, [service]);

  const toggleAudio = useCallback(
    async (muted: boolean) => {
      try {
        await service.toggleAudio(muted);
      } catch (error) {
        console.error('Erro ao alternar áudio:', error);
        throw error;
      }
    },
    [service]
  );

  const toggleVideo = useCallback(
    async (muted: boolean) => {
      try {
        await service.toggleVideo(muted);
      } catch (error) {
        console.error('Erro ao alternar vídeo:', error);
        throw error;
      }
    },
    [service]
  );

  const getJitsiUrl = useCallback(() => {
    try {
      return service.getJitsiUrl();
    } catch (error) {
      console.error('Erro ao obter URL do Jitsi:', error);
      return null;
    }
  }, [service]);

  return {
    state,
    isInitializing,
    initialize,
    disconnect,
    toggleAudio,
    toggleVideo,
    getJitsiUrl,
  };
}
