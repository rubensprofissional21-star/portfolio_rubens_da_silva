/**
 * Hook: usePlayerSettings
 * Gerencia configurações do jogador (nickname, preferências)
 */

import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppSettings } from '@/lib/domain/types';

const DEFAULT_SETTINGS: AppSettings = {
  nickname: 'Aventureiro',
  theme: 'auto',
  audioEnabled: true,
  videoEnabled: true,
  hapticEnabled: true,
  recentRooms: [],
};

export function usePlayerSettings() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [isLoading, setIsLoading] = useState(true);

  // Carregar configurações ao montar
  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const stored = await AsyncStorage.getItem('player_settings');
      if (stored) {
        setSettings(JSON.parse(stored));
      }
    } catch (error) {
      console.error('Erro ao carregar configurações:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateNickname = async (nickname: string) => {
    const updated = { ...settings, nickname };
    setSettings(updated);
    try {
      await AsyncStorage.setItem('player_settings', JSON.stringify(updated));
    } catch (error) {
      console.error('Erro ao salvar nickname:', error);
    }
  };

  const updateTheme = async (theme: 'light' | 'dark' | 'auto') => {
    const updated = { ...settings, theme };
    setSettings(updated);
    try {
      await AsyncStorage.setItem('player_settings', JSON.stringify(updated));
    } catch (error) {
      console.error('Erro ao salvar tema:', error);
    }
  };

  const addRecentRoom = async (roomId: string) => {
    const updated = {
      ...settings,
      recentRooms: [roomId, ...settings.recentRooms.filter(id => id !== roomId)].slice(0, 5),
    };
    setSettings(updated);
    try {
      await AsyncStorage.setItem('player_settings', JSON.stringify(updated));
    } catch (error) {
      console.error('Erro ao atualizar salas recentes:', error);
    }
  };

  return {
    settings,
    isLoading,
    updateNickname,
    updateTheme,
    addRecentRoom,
  };
}
