/**
 * Hook para usar o Mestre de IA com OpenAI
 */

import { useEffect, useState, useCallback } from 'react';
import OpenAIService from '@/lib/services/openai-service';
import { NPC, Quest } from '@/lib/domain/types';

interface UseOpenAIMasterOptions {
  apiKey?: string;
  theme?: string;
  difficulty?: string;
}

export function useOpenAIMaster(options: UseOpenAIMasterOptions = {}) {
  const [service, setService] = useState<OpenAIService | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Inicializar serviço com API key
  useEffect(() => {
    const apiKey = options.apiKey || process.env.EXPO_PUBLIC_OPENAI_API_KEY;
    
    if (apiKey) {
      try {
        const newService = new OpenAIService(apiKey);
        setService(newService);
        setError(null);
      } catch (err) {
        setError('Erro ao inicializar serviço OpenAI');
        console.error('OpenAI Service Error:', err);
      }
    } else {
      setError('API Key da OpenAI não configurada');
    }
  }, [options.apiKey]);

  const generateNarrative = useCallback(
    async (theme: string, difficulty: string): Promise<string> => {
      if (!service) {
        setError('Serviço OpenAI não inicializado');
        return '';
      }

      setIsLoading(true);
      try {
        const narrative = await service.generateInitialNarrative(theme, difficulty);
        setError(null);
        return narrative;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(errorMsg);
        console.error('Erro ao gerar narrativa:', err);
        return '';
      } finally {
        setIsLoading(false);
      }
    },
    [service]
  );

  const generateNPCs = useCallback(
    async (theme: string, count?: number): Promise<NPC[]> => {
      if (!service) {
        setError('Serviço OpenAI não inicializado');
        return [];
      }

      setIsLoading(true);
      try {
        const npcs = await service.generateNPCs(theme, count);
        setError(null);
        return npcs;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(errorMsg);
        console.error('Erro ao gerar NPCs:', err);
        return [];
      } finally {
        setIsLoading(false);
      }
    },
    [service]
  );

  const generateQuest = useCallback(
    async (theme: string, difficulty: string): Promise<Quest | null> => {
      if (!service) {
        setError('Serviço OpenAI não inicializado');
        return null;
      }

      setIsLoading(true);
      try {
        const quest = await service.generateQuest(theme, difficulty);
        setError(null);
        return quest;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(errorMsg);
        console.error('Erro ao gerar quest:', err);
        return null;
      } finally {
        setIsLoading(false);
      }
    },
    [service]
  );

  const respondToAction = useCallback(
    async (action: string, context: string): Promise<string> => {
      if (!service) {
        setError('Serviço OpenAI não inicializado');
        return '';
      }

      setIsLoading(true);
      try {
        const response = await service.respondToPlayerAction(action, context);
        setError(null);
        return response;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(errorMsg);
        console.error('Erro ao responder ação:', err);
        return '';
      } finally {
        setIsLoading(false);
      }
    },
    [service]
  );

  const generateEvent = useCallback(
    async (theme: string, context: string): Promise<string> => {
      if (!service) {
        setError('Serviço OpenAI não inicializado');
        return '';
      }

      setIsLoading(true);
      try {
        const event = await service.generateDynamicEvent(theme, context);
        setError(null);
        return event;
      } catch (err) {
        const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido';
        setError(errorMsg);
        console.error('Erro ao gerar evento:', err);
        return '';
      } finally {
        setIsLoading(false);
      }
    },
    [service]
  );

  const resetConversation = useCallback(() => {
    if (service) {
      service.resetConversation();
    }
  }, [service]);

  return {
    isReady: !!service,
    isLoading,
    error,
    generateNarrative,
    generateNPCs,
    generateQuest,
    respondToAction,
    generateEvent,
    resetConversation,
  };
}
