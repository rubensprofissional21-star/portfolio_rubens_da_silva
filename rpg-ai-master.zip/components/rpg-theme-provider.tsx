/**
 * RPG Theme Provider - Temas visuais épicos por tipo de aventura
 */

import React, { createContext, useContext } from 'react';
import { type RoomTheme } from '@/lib/domain/types';

export interface RPGThemeColors {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  text: string;
  textSecondary: string;
  border: string;
  success: string;
  warning: string;
  error: string;
  info: string;
  // RPG Specific
  narrativeBackground: string;
  npcBackground: string;
  questBackground: string;
  actionButtonBg: string;
  healthBar: string;
  manaBar: string;
}

export interface RPGThemeStyle {
  colors: RPGThemeColors;
  name: RoomTheme;
  emoji: string;
  description: string;
  borderStyle: string;
  shadowStyle: string;
}

const THEME_CONFIGS: Record<RoomTheme, RPGThemeStyle> = {
  medieval: {
    name: 'medieval',
    emoji: '🏰',
    description: 'Fantasia Medieval',
    colors: {
      primary: '#8B4513', // Marrom
      secondary: '#DAA520', // Ouro
      accent: '#DC143C', // Vermelho
      background: '#1a1410',
      surface: '#2d2620',
      text: '#F5DEB3', // Bege claro
      textSecondary: '#D2B48C',
      border: '#8B4513',
      success: '#228B22',
      warning: '#FFD700',
      error: '#DC143C',
      info: '#4169E1',
      narrativeBackground: '#2d2620',
      npcBackground: '#3d3228',
      questBackground: '#2d2620',
      actionButtonBg: '#8B4513',
      healthBar: '#228B22',
      manaBar: '#4169E1',
    },
    borderStyle: 'border-2 border-amber-700',
    shadowStyle: 'shadow-lg',
  },
  scifi: {
    name: 'scifi',
    emoji: '🚀',
    description: 'Ficção Científica',
    colors: {
      primary: '#00CED1', // Ciano
      secondary: '#00FF00', // Verde neon
      accent: '#FF00FF', // Magenta
      background: '#0a0e27',
      surface: '#1a1f3a',
      text: '#00FF00',
      textSecondary: '#00CED1',
      border: '#00CED1',
      success: '#00FF00',
      warning: '#FFD700',
      error: '#FF0000',
      info: '#00CED1',
      narrativeBackground: '#1a1f3a',
      npcBackground: '#2a2f4a',
      questBackground: '#1a1f3a',
      actionButtonBg: '#00CED1',
      healthBar: '#00FF00',
      manaBar: '#FF00FF',
    },
    borderStyle: 'border-2 border-cyan-400',
    shadowStyle: 'shadow-lg shadow-cyan-500/50',
  },
  horror: {
    name: 'horror',
    emoji: '👻',
    description: 'Horror',
    colors: {
      primary: '#8B008B', // Roxo escuro
      secondary: '#DC143C', // Vermelho
      accent: '#FF4500', // Laranja escuro
      background: '#0d0d0d',
      surface: '#1a1a1a',
      text: '#E6E6FA', // Lavanda claro
      textSecondary: '#A9A9A9',
      border: '#8B008B',
      success: '#00FF00',
      warning: '#DC143C',
      error: '#FF0000',
      info: '#8B008B',
      narrativeBackground: '#1a1a1a',
      npcBackground: '#2a2a2a',
      questBackground: '#1a1a1a',
      actionButtonBg: '#8B008B',
      healthBar: '#DC143C',
      manaBar: '#8B008B',
    },
    borderStyle: 'border-2 border-purple-900',
    shadowStyle: 'shadow-lg shadow-red-900/50',
  },
  fantasy: {
    name: 'fantasy',
    emoji: '✨',
    description: 'Fantasia Mágica',
    colors: {
      primary: '#9370DB', // Roxo médio
      secondary: '#FFD700', // Ouro
      accent: '#FF69B4', // Rosa quente
      background: '#1a0f2e',
      surface: '#2d1b4e',
      text: '#E6D5FF', // Lavanda claro
      textSecondary: '#B8A8D8',
      border: '#9370DB',
      success: '#00FF7F',
      warning: '#FFD700',
      error: '#FF1493',
      info: '#87CEEB',
      narrativeBackground: '#2d1b4e',
      npcBackground: '#3d2b5e',
      questBackground: '#2d1b4e',
      actionButtonBg: '#9370DB',
      healthBar: '#00FF7F',
      manaBar: '#87CEEB',
    },
    borderStyle: 'border-2 border-purple-500',
    shadowStyle: 'shadow-lg shadow-purple-500/50',
  },
};

const RPGThemeContext = createContext<RPGThemeStyle | null>(null);

interface RPGThemeProviderProps {
  theme: RoomTheme;
  children: React.ReactNode;
}

export function RPGThemeProvider({ theme, children }: RPGThemeProviderProps) {
  const themeStyle = THEME_CONFIGS[theme];

  return (
    <RPGThemeContext.Provider value={themeStyle}>
      {children}
    </RPGThemeContext.Provider>
  );
}

export function useRPGTheme(): RPGThemeStyle {
  const context = useContext(RPGThemeContext);
  if (!context) {
    // Fallback para medieval se não houver provider
    return THEME_CONFIGS.medieval;
  }
  return context;
}

export function getRPGTheme(theme: RoomTheme): RPGThemeStyle {
  return THEME_CONFIGS[theme];
}
