import { View, Text, Image, ScrollView, Pressable } from 'react-native';
import { useRouter } from 'expo-router';
import { useColors } from '@/hooks/use-colors';
import { ScreenContainer } from './screen-container';

export function HomeHero() {
  const router = useRouter();
  const colors = useColors();

  const handleCreateRoom = () => {
    router.push('/create-room');
  };

  const handleJoinRoom = () => {
    router.push('/join-room');
  };

  const handleSettings = () => {
    router.push('/settings');
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        {/* Hero Banner */}
        <View className="w-full h-64 relative overflow-hidden">
          <Image
            source={require('@/assets/images/hero-banner.png')}
            className="w-full h-full"
            resizeMode="cover"
          />
          <View className="absolute inset-0 bg-black/30" />
          
          {/* Hero Content */}
          <View className="absolute inset-0 flex items-center justify-center gap-3 px-6">
            <Text className="text-5xl font-bold text-white text-center drop-shadow-lg">
              RPG AI Master
            </Text>
            <Text className="text-lg text-white/90 text-center drop-shadow-md">
              Embarque em aventuras épicas guiadas por um Mestre de IA
            </Text>
          </View>
        </View>

        {/* Main Content */}
        <View className="flex-1 px-6 py-8 gap-8">
          {/* Welcome Section */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">
              Bem-vindo de volta, Aventureiro 🎭
            </Text>
            <Text className="text-sm text-muted">
              Prepare-se para uma jornada inesquecível
            </Text>
          </View>

          {/* Action Cards */}
          <View className="gap-4">
            {/* Create Room Card */}
            <Pressable
              onPress={handleCreateRoom}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.98 : 1 }],
                },
              ]}
              className="rounded-2xl overflow-hidden border border-border"
            >
              <Image
                source={require('@/assets/images/card-create-room.png')}
                className="w-full h-48"
                resizeMode="cover"
              />
              <View className="bg-surface p-4 gap-2">
                <Text className="text-xl font-bold text-foreground">🎭 Criar Nova Sala</Text>
                <Text className="text-sm text-muted">
                  Crie uma sala e convide amigos para uma aventura épica
                </Text>
              </View>
            </Pressable>

            {/* Join Room Card */}
            <Pressable
              onPress={handleJoinRoom}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.98 : 1 }],
                },
              ]}
              className="rounded-2xl overflow-hidden border border-border"
            >
              <Image
                source={require('@/assets/images/card-join-room.png')}
                className="w-full h-48"
                resizeMode="cover"
              />
              <View className="bg-surface p-4 gap-2">
                <Text className="text-xl font-bold text-foreground">🚪 Entrar em Sala</Text>
                <Text className="text-sm text-muted">
                  Junte-se a uma sala existente e compartilhe a aventura
                </Text>
              </View>
            </Pressable>

            {/* AI Master Card */}
            <View className="rounded-2xl overflow-hidden border border-border">
              <Image
                source={require('@/assets/images/card-ai-master.png')}
                className="w-full h-48"
                resizeMode="cover"
              />
              <View className="bg-surface p-4 gap-2">
                <Text className="text-xl font-bold text-foreground">🧙 Mestre de IA</Text>
                <Text className="text-sm text-muted">
                  Uma IA generativa conduz a narrativa em tempo real
                </Text>
              </View>
            </View>
          </View>

          {/* How It Works Section */}
          <View className="gap-4">
            <Text className="text-2xl font-bold text-foreground">COMO FUNCIONA</Text>
            
            <View className="flex-row gap-3 items-start">
              <Text className="text-3xl">🎭</Text>
              <View className="flex-1 gap-1">
                <Text className="font-semibold text-foreground">Crie uma Sala</Text>
                <Text className="text-xs text-muted">
                  Escolha um tema (Medieval, Sci-Fi, Horror, Fantasy) e configure a dificuldade
                </Text>
              </View>
            </View>

            <View className="flex-row gap-3 items-start">
              <Text className="text-3xl">📹</Text>
              <View className="flex-1 gap-1">
                <Text className="font-semibold text-foreground">Videoconferência</Text>
                <Text className="text-xs text-muted">
                  Conecte-se com outros jogadores via Jitsi Meet integrado
                </Text>
              </View>
            </View>

            <View className="flex-row gap-3 items-start">
              <Text className="text-3xl">🧠</Text>
              <View className="flex-1 gap-1">
                <Text className="font-semibold text-foreground">Mestre de IA</Text>
                <Text className="text-xs text-muted">
                  A IA conduz a narrativa, cria NPCs e quests adaptadas às suas ações
                </Text>
              </View>
            </View>
          </View>

          {/* Settings Button */}
          <Pressable
            onPress={handleSettings}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.7 : 1,
              },
            ]}
            className="flex-row items-center justify-center gap-2 bg-surface rounded-xl p-4 border border-border"
          >
            <Text className="text-xl">⚙️</Text>
            <Text className="font-semibold text-foreground">Configurações</Text>
          </Pressable>

          {/* Footer */}
          <View className="items-center gap-2 pb-4">
            <Text className="text-xs text-muted">Versão 1.0.0</Text>
            <Text className="text-xs text-muted">Desenvolvido com ❤️ para jogadores de RPG</Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
