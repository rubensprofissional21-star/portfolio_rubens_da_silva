/**
 * Character Sheet - Ficha de personagem com visual RPG profissional
 */

import React from 'react';
import { ScrollView, Text, View, ProgressBarAndroid } from 'react-native';
import { useRPGTheme } from './rpg-theme-provider';
import { type Character } from '@/lib/domain/types';

interface CharacterSheetProps {
  character: Character;
}

export function CharacterSheet({ character }: CharacterSheetProps) {
  const rpgTheme = useRPGTheme();

  const healthPercent = character.health / character.maxHealth;
  const manaPercent = character.mana / character.maxMana;
  const xpPercent = (character.experience % 1000) / 1000;

  const ProgressBar = ({ percent, color }: { percent: number; color: string }) => (
    <View
      className="h-2 rounded-full overflow-hidden"
      style={{ backgroundColor: rpgTheme.colors.border }}
    >
      <View
        className="h-full"
        style={{
          backgroundColor: color,
          width: `${Math.max(0, Math.min(100, percent * 100))}%`,
        }}
      />
    </View>
  );

  return (
    <ScrollView
      className="flex-1 p-4"
      style={{ backgroundColor: rpgTheme.colors.background }}
      contentContainerStyle={{ paddingBottom: 20 }}
    >
      {/* Header - Nome e Classe */}
      <View
        className="p-4 rounded-lg mb-4 border-2"
        style={{
          backgroundColor: rpgTheme.colors.surface,
          borderColor: rpgTheme.colors.primary,
        }}
      >
        <Text
          className="text-2xl font-bold"
          style={{ color: rpgTheme.colors.secondary }}
        >
          {character.name}
        </Text>
        <Text
          className="text-sm mt-1"
          style={{ color: rpgTheme.colors.textSecondary }}
        >
          {character.class} • Nível {character.level}
        </Text>
      </View>

      {/* Vida e Mana */}
      <View
        className="p-4 rounded-lg mb-4"
        style={{ backgroundColor: rpgTheme.colors.surface }}
      >
        <View className="mb-4">
          <View className="flex-row justify-between items-center mb-2">
            <Text style={{ color: rpgTheme.colors.healthBar }}>❤️ Vida</Text>
            <Text
              className="text-sm"
              style={{ color: rpgTheme.colors.textSecondary }}
            >
              {character.health} / {character.maxHealth}
            </Text>
          </View>
          <ProgressBar percent={healthPercent} color={rpgTheme.colors.healthBar} />
        </View>

        <View>
          <View className="flex-row justify-between items-center mb-2">
            <Text style={{ color: rpgTheme.colors.manaBar }}>💙 Mana</Text>
            <Text
              className="text-sm"
              style={{ color: rpgTheme.colors.textSecondary }}
            >
              {character.mana} / {character.maxMana}
            </Text>
          </View>
          <ProgressBar percent={manaPercent} color={rpgTheme.colors.manaBar} />
        </View>
      </View>

      {/* Experiência */}
      <View
        className="p-4 rounded-lg mb-4"
        style={{ backgroundColor: rpgTheme.colors.surface }}
      >
        <View className="flex-row justify-between items-center mb-2">
          <Text style={{ color: rpgTheme.colors.info }}>⭐ Experiência</Text>
          <Text
            className="text-sm"
            style={{ color: rpgTheme.colors.textSecondary }}
          >
            {character.experience % 1000} / 1000
          </Text>
        </View>
        <ProgressBar percent={xpPercent} color={rpgTheme.colors.info} />
      </View>

      {/* Atributos */}
      <View
        className="p-4 rounded-lg mb-4"
        style={{ backgroundColor: rpgTheme.colors.surface }}
      >
        <Text
          className="text-lg font-bold mb-3"
          style={{ color: rpgTheme.colors.primary }}
        >
          ⚔️ Atributos
        </Text>

        <View className="gap-3">
          <AttributeRow
            icon="💪"
            label="Força"
            value={character.attributes.strength}
            theme={rpgTheme}
          />
          <AttributeRow
            icon="🧠"
            label="Inteligência"
            value={character.attributes.intelligence}
            theme={rpgTheme}
          />
          <AttributeRow
            icon="⚡"
            label="Destreza"
            value={character.attributes.dexterity}
            theme={rpgTheme}
          />
          <AttributeRow
            icon="🛡️"
            label="Constituição"
            value={character.attributes.constitution}
            theme={rpgTheme}
          />
          <AttributeRow
            icon="✨"
            label="Sabedoria"
            value={character.attributes.wisdom}
            theme={rpgTheme}
          />
          <AttributeRow
            icon="🎭"
            label="Carisma"
            value={character.attributes.charisma}
            theme={rpgTheme}
          />
        </View>
      </View>

      {/* Inventário */}
      {character.inventory.length > 0 && (
        <View
          className="p-4 rounded-lg"
          style={{ backgroundColor: rpgTheme.colors.surface }}
        >
          <Text
            className="text-lg font-bold mb-3"
            style={{ color: rpgTheme.colors.primary }}
          >
            🎒 Inventário ({character.inventory.length})
          </Text>

          <View className="gap-2">
            {character.inventory.map((item, index) => (
              <View
                key={index}
                className="p-2 rounded flex-row justify-between items-center"
                style={{
                  backgroundColor: rpgTheme.colors.background,
                  borderLeftWidth: 3,
                  borderLeftColor: getRarityColor(item.rarity, rpgTheme),
                }}
              >
                <Text style={{ color: rpgTheme.colors.text }}>{item.name}</Text>
                <Text
                  className="text-xs"
                  style={{
                    color: getRarityColor(item.rarity, rpgTheme),
                  }}
                >
                  {item.rarity.toUpperCase()}
                </Text>
              </View>
            ))}
          </View>
        </View>
      )}
    </ScrollView>
  );
}

function AttributeRow({
  icon,
  label,
  value,
  theme,
}: {
  icon: string;
  label: string;
  value: number;
  theme: any;
}) {
  return (
    <View className="flex-row justify-between items-center">
      <Text style={{ color: theme.colors.text }}>
        {icon} {label}
      </Text>
      <View
        className="px-3 py-1 rounded"
        style={{ backgroundColor: theme.colors.primary }}
      >
        <Text
          className="font-bold text-sm"
          style={{ color: theme.colors.background }}
        >
          +{value}
        </Text>
      </View>
    </View>
  );
}

function getRarityColor(rarity: string, theme: any): string {
  switch (rarity) {
    case 'legendary':
      return '#FFD700'; // Ouro
    case 'epic':
      return '#9370DB'; // Roxo
    case 'rare':
      return '#4169E1'; // Azul
    case 'uncommon':
      return '#00FF00'; // Verde
    case 'common':
    default:
      return theme.colors.textSecondary;
  }
}
