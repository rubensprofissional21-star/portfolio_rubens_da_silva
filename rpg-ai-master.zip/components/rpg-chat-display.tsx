/**
 * RPG Chat Display - Chat com estilo narrativo de RPG
 */

import React from 'react';
import { ScrollView, Text, View, TextInput, TouchableOpacity } from 'react-native';
import { useRPGTheme } from './rpg-theme-provider';

export interface ChatMessage {
  id: string;
  sender: 'player' | 'master';
  content: string;
  timestamp: number;
  isTyping?: boolean;
}

interface RPGChatDisplayProps {
  messages: ChatMessage[];
  playerName: string;
  onSendMessage: (message: string) => void;
  isLoading?: boolean;
}

export function RPGChatDisplay({
  messages,
  playerName,
  onSendMessage,
  isLoading,
}: RPGChatDisplayProps) {
  const rpgTheme = useRPGTheme();
  const [inputText, setInputText] = React.useState('');

  const handleSend = () => {
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  return (
    <View className="flex-1" style={{ backgroundColor: rpgTheme.colors.background }}>
      {/* Chat Messages */}
      <ScrollView
        className="flex-1 p-4"
        contentContainerStyle={{ paddingBottom: 20 }}
      >
        {messages.length === 0 ? (
          <View className="flex-1 items-center justify-center py-8">
            <Text
              className="text-center text-lg"
              style={{ color: rpgTheme.colors.textSecondary }}
            >
              Comece a conversa com o Mestre...
            </Text>
          </View>
        ) : (
          messages.map((msg) => (
            <View
              key={msg.id}
              className={`mb-4 ${msg.sender === 'player' ? 'items-end' : 'items-start'}`}
            >
              {/* Nome do remetente */}
              <Text
                className="text-xs font-bold mb-1"
                style={{
                  color:
                    msg.sender === 'player'
                      ? rpgTheme.colors.accent
                      : rpgTheme.colors.secondary,
                }}
              >
                {msg.sender === 'player' ? playerName : '🎭 Mestre de IA'}
              </Text>

              {/* Mensagem */}
              <View
                className="px-4 py-3 rounded-lg max-w-xs"
                style={{
                  backgroundColor:
                    msg.sender === 'player'
                      ? rpgTheme.colors.actionButtonBg
                      : rpgTheme.colors.npcBackground,
                  borderLeftWidth: 3,
                  borderLeftColor:
                    msg.sender === 'player'
                      ? rpgTheme.colors.accent
                      : rpgTheme.colors.secondary,
                }}
              >
                <Text
                  className="text-sm leading-relaxed"
                  style={{ color: rpgTheme.colors.text }}
                >
                  {msg.content}
                </Text>
              </View>

              {/* Typing indicator */}
              {msg.isTyping && (
                <Text
                  className="text-xs mt-1"
                  style={{ color: rpgTheme.colors.textSecondary }}
                >
                  ✍️ digitando...
                </Text>
              )}

              {/* Timestamp */}
              <Text
                className="text-xs mt-1"
                style={{ color: rpgTheme.colors.textSecondary }}
              >
                {new Date(msg.timestamp).toLocaleTimeString('pt-BR', {
                  hour: '2-digit',
                  minute: '2-digit',
                })}
              </Text>
            </View>
          ))
        )}
      </ScrollView>

      {/* Input Area */}
      <View
        className="border-t p-4"
        style={{
          backgroundColor: rpgTheme.colors.surface,
          borderTopColor: rpgTheme.colors.border,
        }}
      >
        <View className="flex-row gap-2 items-center">
          <TextInput
            className="flex-1 px-4 py-3 rounded-lg text-sm"
            placeholder="Sua ação ou mensagem..."
            placeholderTextColor={rpgTheme.colors.textSecondary}
            value={inputText}
            onChangeText={setInputText}
            editable={!isLoading}
            style={{
              backgroundColor: rpgTheme.colors.background,
              color: rpgTheme.colors.text,
              borderWidth: 1,
              borderColor: rpgTheme.colors.border,
            }}
          />
          <TouchableOpacity
            onPress={handleSend}
            disabled={isLoading || !inputText.trim()}
            className="px-4 py-3 rounded-lg"
            style={{
              backgroundColor: inputText.trim()
                ? rpgTheme.colors.primary
                : rpgTheme.colors.textSecondary,
              opacity: isLoading ? 0.5 : 1,
            }}
          >
            <Text
              className="font-bold"
              style={{ color: rpgTheme.colors.background }}
            >
              →
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
