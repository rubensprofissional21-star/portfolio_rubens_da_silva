/**
 * Narrative Redesigned - Narrativa com estilo épico de RPG
 */

import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { type NPC } from '@/lib/domain/types';

interface NarrativeRedesignedProps {
  narrativeText: string;
  npcs: NPC[];
  theme: string;
}

export function NarrativeRedesigned({ narrativeText, npcs, theme }: NarrativeRedesignedProps) {
  const getThemeColors = () => {
    switch (theme) {
      case 'medieval':
        return { bg: 'from-amber-950 to-amber-900', border: 'border-amber-700', text: 'text-amber-100', title: 'text-amber-300' };
      case 'scifi':
        return { bg: 'from-cyan-950 to-cyan-900', border: 'border-cyan-700', text: 'text-cyan-100', title: 'text-cyan-300' };
      case 'horror':
        return { bg: 'from-red-950 to-red-900', border: 'border-red-700', text: 'text-red-100', title: 'text-red-300' };
      default:
        return { bg: 'from-purple-950 to-purple-900', border: 'border-purple-700', text: 'text-purple-100', title: 'text-purple-300' };
    }
  };

  const colors = getThemeColors();

  return (
    <ScrollView className={`flex-1 bg-gradient-to-b ${colors.bg}`} showsVerticalScrollIndicator={false}>
      <View className="px-4 py-6 gap-6">
        {/* Main Narrative */}
        <View className={`border-l-4 ${colors.border} pl-4`}>
          <Text className={`text-lg font-bold ${colors.title} mb-3`}>📖 NARRATIVA</Text>
          <Text className={`text-sm leading-relaxed ${colors.text}`}>{narrativeText}</Text>
        </View>

        {/* NPCs */}
        {npcs.length > 0 && (
          <View className="gap-3">
            <Text className={`text-lg font-bold ${colors.title}`}>🎭 PERSONAGENS</Text>
            {npcs.map((npc) => (
              <View
                key={npc.id}
                className={`bg-gradient-to-br from-slate-800 to-slate-900 border-l-4 ${colors.border} rounded-lg p-4`}
              >
                <View className="flex-row items-start gap-3">
                  <Text className="text-2xl">{npc.id === '1' ? '🧙' : '⚔️'}</Text>
                  <View className="flex-1">
                    <Text className={`text-base font-bold ${colors.title}`}>{npc.name}</Text>
                    <Text className={`text-xs ${colors.text} italic mt-1`}>{npc.personality}</Text>
                    <Text className={`text-xs ${colors.text} mt-2 leading-relaxed`}>{npc.backstory}</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}
      </View>
    </ScrollView>
  );
}
