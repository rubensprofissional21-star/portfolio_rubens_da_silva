/**
 * RPG Chat Immersive - Chat com efeitos visuais imersivos
 * Gradientes, sombras, transições e animações épicas
 */

import React, { useState } from 'react';
import { View, Text, ScrollView, TextInput, Pressable } from 'react-native';
import { cn } from '@/lib/utils';
import { visualEffectsTheme, transitionEffects } from '@/lib/theme/visual-effects';
import type { RoomTheme } from '@/lib/domain/types';

interface Message {
  id: string;
  sender: 'player' | 'master';
  text: string;
  timestamp: string;
}

interface RPGChatImmersiveProps {
  messages: Message[];
  onSendMessage: (message: string) => void;
  onQuickAction: (action: string) => void;
  theme: RoomTheme;
  isLoading?: boolean;
}

export function RPGChatImmersive({
  messages,
  onSendMessage,
  onQuickAction,
  theme,
  isLoading,
}: RPGChatImmersiveProps) {
  const [inputValue, setInputValue] = useState('');
  const themeColors = visualEffectsTheme[theme as keyof typeof visualEffectsTheme] || visualEffectsTheme.medieval;

  const quickActions = [
    { icon: '⚔️', label: 'Atacar', action: 'attack' },
    { icon: '🛡️', label: 'Defender', action: 'defend' },
    { icon: '💬', label: 'Conversar', action: 'talk' },
    { icon: '🔍', label: 'Investigar', action: 'investigate' },
  ];

  const handleSendMessage = () => {
    if (inputValue.trim()) {
      onSendMessage(inputValue);
      setInputValue('');
    }
  };

  return (
    <View className="flex-1 flex-col gap-4 p-4" style={{ backgroundColor: 'rgba(0, 0, 0, 0.3)' }}>
      {/* Messages Container */}
      <ScrollView
        className="flex-1 gap-3"
        contentContainerStyle={{ paddingBottom: 16 }}
        showsVerticalScrollIndicator={false}
      >
        {messages.length === 0 ? (
          <View className="flex-1 items-center justify-center py-8">
            <Text className="text-center text-muted text-sm">
              Comece sua aventura falando com o Mestre...
            </Text>
          </View>
        ) : (
          messages.map((msg) => (
            <View
              key={msg.id}
              className={cn(
                'rounded-lg p-4 max-w-xs border-l-4',
                msg.sender === 'master' ? 'self-start' : 'self-end'
              )}
              style={{
                borderLeftColor: msg.sender === 'master' ? themeColors.accentColor : 'transparent',
                backgroundColor: msg.sender === 'master' ? 'rgba(100, 100, 150, 0.4)' : 'rgba(100, 100, 150, 0.6)',
              }}
            >
              <Text className="text-xs font-semibold mb-1" style={{ color: themeColors.accentColor }}>
                {msg.sender === 'master' ? '🎭 MESTRE' : '🧙 VOCÊ'}
              </Text>
              <Text className="text-sm leading-relaxed" style={{ color: themeColors.textColor }}>
                {msg.text}
              </Text>
              <Text className="text-xs mt-2 opacity-60" style={{ color: themeColors.textColor }}>
                {msg.timestamp}
              </Text>
            </View>
          ))
        )}
        {isLoading && (
          <View className="self-start">
            <View
              className="rounded-lg p-4 gap-2"
              style={{
                backgroundColor: 'rgba(100, 100, 150, 0.5)',
              }}
            >
              <Text className="text-xs font-semibold" style={{ color: themeColors.accentColor }}>
                🎭 MESTRE
              </Text>
              <View className="flex-row gap-1">
                <View className="w-2 h-2 rounded-full bg-opacity-60" style={{ backgroundColor: themeColors.accentColor }} />
                <View className="w-2 h-2 rounded-full bg-opacity-60" style={{ backgroundColor: themeColors.accentColor }} />
                <View className="w-2 h-2 rounded-full bg-opacity-60" style={{ backgroundColor: themeColors.accentColor }} />
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Quick Actions */}
      <View className="flex-row gap-2 justify-center flex-wrap">
        {quickActions.map((action) => (
          <Pressable
            key={action.action}
            onPress={() => onQuickAction(action.action)}
            className="px-3 py-2 rounded-lg flex-row items-center gap-1"
            style={{
              backgroundColor: 'rgba(100, 100, 150, 0.5)',
              borderWidth: 1,
              borderColor: themeColors.borderColor,
            }}
          >
            <Text className="text-lg">{action.icon}</Text>
            <Text className="text-xs font-semibold" style={{ color: themeColors.textColor }}>
              {action.label}
            </Text>
          </Pressable>
        ))}
      </View>

      {/* Input Area */}
      <View
        className="flex-row gap-2 items-center rounded-lg p-3"
        style={{
          backgroundColor: 'rgba(100, 100, 150, 0.5)',
          borderWidth: 1,
          borderColor: themeColors.borderColor,
        }}
      >
        <TextInput
          value={inputValue}
          onChangeText={setInputValue}
          placeholder="Digite sua ação..."
          placeholderTextColor={themeColors.textColor + '80'}
          className="flex-1 text-sm"
          style={{
            color: themeColors.textColor,
            paddingVertical: 8,
          }}
        />
        <Pressable
          onPress={handleSendMessage}
          disabled={!inputValue.trim() || isLoading}
          className="px-4 py-2 rounded-lg"
          style={{
            backgroundColor: inputValue.trim() && !isLoading ? themeColors.accentColor : 'rgba(100, 100, 100, 0.5)',
            opacity: inputValue.trim() && !isLoading ? 1 : 0.6,
          }}
        >
          <Text className="font-semibold text-sm" style={{ color: '#000' }}>
            →
          </Text>
        </Pressable>
      </View>
    </View>
  );
}
