/**
 * Quests Display - Exibição de quests com cards visuais
 */

import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useRPGTheme } from './rpg-theme-provider';
import { type Quest } from '@/lib/domain/types';

interface QuestsDisplayProps {
  quests: Quest[];
}

export function QuestsDisplay({ quests }: QuestsDisplayProps) {
  const rpgTheme = useRPGTheme();

  const getQuestStatus = (quest: Quest) => {
    if (quest.status === 'completed') return '✅ Concluída';
    if (quest.status === 'active') return '🔥 Ativa';
    return '❌ Falhada';
  };

  const getQuestStatusColor = (quest: Quest) => {
    if (quest.status === 'completed') return rpgTheme.colors.success;
    if (quest.status === 'active') return rpgTheme.colors.accent;
    return rpgTheme.colors.error;
  };

  return (
    <ScrollView
      className="flex-1 p-4"
      style={{ backgroundColor: rpgTheme.colors.background }}
      contentContainerStyle={{ paddingBottom: 20 }}
    >
      {quests.length === 0 ? (
        <View className="flex-1 items-center justify-center py-8">
          <Text
            className="text-center text-lg"
            style={{ color: rpgTheme.colors.textSecondary }}
          >
            Nenhuma quest disponível no momento...
          </Text>
        </View>
      ) : (
        quests.map((quest) => (
          <View
            key={quest.id}
            className="mb-4 p-4 rounded-lg border-2"
            style={{
              backgroundColor: rpgTheme.colors.questBackground,
              borderColor: getQuestStatusColor(quest),
              opacity: quest.status === 'completed' ? 0.7 : 1,
            }}
          >
            {/* Header - Título e Status */}
            <View className="flex-row justify-between items-start mb-3">
              <View className="flex-1 pr-2">
                <Text
                  className="text-lg font-bold"
                  style={{ color: rpgTheme.colors.secondary }}
                >
                  {quest.title}
                </Text>
                <Text
                  className="text-xs mt-1"
                  style={{ color: rpgTheme.colors.textSecondary }}
                >
                  Dificuldade: {quest.difficulty.toUpperCase()}
                </Text>
              </View>
              <View
                className="px-2 py-1 rounded"
                style={{ backgroundColor: getQuestStatusColor(quest) }}
              >
                <Text
                  className="text-xs font-bold"
                  style={{ color: rpgTheme.colors.background }}
                >
                  {getQuestStatus(quest)}
                </Text>
              </View>
            </View>

            {/* Descrição */}
            <Text
              className="text-sm leading-relaxed mb-3"
              style={{ color: rpgTheme.colors.text }}
            >
              {quest.description}
            </Text>

            {/* Objetivos */}
            <View className="mb-3">
              <Text
                className="text-xs font-bold mb-2"
                style={{ color: rpgTheme.colors.primary }}
              >
                🎯 OBJETIVOS
              </Text>
              {quest.objectives.map((objective, index) => (
                <View key={index} className="flex-row items-start ml-2 mb-1">
                  <Text
                    className="mr-2"
                    style={{ color: rpgTheme.colors.textSecondary }}
                  >
                    ○
                  </Text>
                  <Text
                    className="flex-1 text-xs"
                    style={{
                      color: rpgTheme.colors.text,
                    }}
                  >
                    {objective}
                  </Text>
                </View>
              ))}
            </View>

            {/* Recompensas */}
            <View
              className="p-2 rounded"
              style={{ backgroundColor: rpgTheme.colors.npcBackground }}
            >
              <Text
                className="text-xs font-bold mb-2"
                style={{ color: rpgTheme.colors.secondary }}
              >
                🏆 RECOMPENSAS
              </Text>
              <View className="gap-1">
                {quest.rewards.map((reward, index) => (
                  <Text
                    key={index}
                    className="text-xs"
                    style={{ color: rpgTheme.colors.text }}
                  >
                    • +{reward.amount} {reward.type === 'experience' ? 'XP' : reward.type === 'gold' ? 'Ouro' : reward.item?.name || 'Item'}
                  </Text>
                ))}
              </View>
            </View>

            {/* Progresso (se ativa) */}
            {quest.status === 'active' && (
              <View className="mt-3">
                <View className="flex-row justify-between items-center mb-1">
                  <Text
                    className="text-xs"
                    style={{ color: rpgTheme.colors.info }}
                  >
                    Progresso
                  </Text>
                  <Text
                    className="text-xs"
                    style={{ color: rpgTheme.colors.textSecondary }}
                  >
                    {Math.round(quest.progress * 100)}%
                  </Text>
                </View>
                <View
                  className="h-2 rounded-full overflow-hidden"
                  style={{ backgroundColor: rpgTheme.colors.border }}
                >
                  <View
                    className="h-full"
                    style={{
                      backgroundColor: rpgTheme.colors.info,
                      width: `${quest.progress * 100}%`,
                    }}
                  />
                </View>
              </View>
            )}
          </View>
        ))
      )}
    </ScrollView>
  );
}
