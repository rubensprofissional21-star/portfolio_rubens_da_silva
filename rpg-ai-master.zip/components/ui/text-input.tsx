/**
 * TextInput - Componente de entrada de texto customizado
 * Segue padrão de Material Design 3
 */

import React from 'react';
import { TextInput as RNTextInput, View, Text, StyleSheet, TextInputProps } from 'react-native';
import { useColors } from '@/hooks/use-colors';
import { cn } from '@/lib/utils';

interface CustomTextInputProps extends TextInputProps {
  label?: string;
  error?: string;
  containerClassName?: string;
  inputClassName?: string;
}

export function TextInput({
  label,
  error,
  containerClassName,
  inputClassName,
  ...props
}: CustomTextInputProps) {
  const colors = useColors();

  return (
    <View className={cn('gap-2', containerClassName)}>
      {label && (
        <Text className="text-sm font-medium text-foreground">{label}</Text>
      )}
      <RNTextInput
        {...props}
        style={[
          styles.input,
          {
            borderColor: error ? colors.error : colors.border,
            color: colors.foreground,
            backgroundColor: colors.surface,
          },
          props.style,
        ]}
        placeholderTextColor={colors.muted}
        className={cn(
          'px-4 py-3 rounded-lg border',
          inputClassName
        )}
      />
      {error && (
        <Text className="text-xs font-medium text-error">{error}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    fontSize: 16,
    lineHeight: 24,
    borderWidth: 1,
  },
});
