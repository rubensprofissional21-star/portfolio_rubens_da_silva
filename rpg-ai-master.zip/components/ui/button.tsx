/**
 * Button - Componente de botão customizado
 * Segue padrão de Material Design 3 com feedback háptico
 */

import React from 'react';
import { Pressable, Text, StyleSheet, PressableProps, ActivityIndicator } from 'react-native';
import * as Haptics from 'expo-haptics';
import { useColors } from '@/hooks/use-colors';
import { cn } from '@/lib/utils';

interface ButtonProps extends PressableProps {
  label: string;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'small' | 'medium' | 'large';
  isLoading?: boolean;
  disabled?: boolean;
  className?: string;
}

export function Button({
  label,
  variant = 'primary',
  size = 'medium',
  isLoading = false,
  disabled = false,
  className,
  onPress,
  ...props
}: ButtonProps) {
  const colors = useColors();

  const handlePress = async (e: any) => {
    if (!disabled && !isLoading) {
      try {
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      } catch {
        // Haptics não disponível em web
      }
      onPress?.(e);
    }
  };

  const getVariantStyles = () => {
    switch (variant) {
      case 'primary':
        return {
          backgroundColor: colors.primary,
          borderColor: colors.primary,
        };
      case 'secondary':
        return {
          backgroundColor: colors.surface,
          borderColor: colors.border,
        };
      case 'outline':
        return {
          backgroundColor: 'transparent',
          borderColor: colors.primary,
        };
      case 'ghost':
        return {
          backgroundColor: 'transparent',
          borderColor: 'transparent',
        };
      default:
        return {};
    }
  };

  const getSizeStyles = () => {
    switch (size) {
      case 'small':
        return 'px-4 py-2';
      case 'medium':
        return 'px-6 py-3';
      case 'large':
        return 'px-8 py-4';
      default:
        return 'px-6 py-3';
    }
  };

  const getTextColor = () => {
    if (variant === 'primary') return colors.background;
    if (variant === 'outline') return colors.primary;
    return colors.foreground;
  };

  return (
    <Pressable
      {...props}
      disabled={disabled || isLoading}
      onPress={handlePress}
      style={({ pressed }) => [
        styles.button,
        {
          ...getVariantStyles(),
          opacity: pressed ? 0.8 : disabled ? 0.5 : 1,
          transform: pressed ? [{ scale: 0.97 }] : [{ scale: 1 }],
        },
      ]}
      className={cn(
        'rounded-lg border flex-row items-center justify-center',
        getSizeStyles(),
        className
      )}
    >
      {isLoading ? (
        <ActivityIndicator color={getTextColor()} size="small" />
      ) : (
        <Text
          className="font-semibold text-center"
          style={{ color: getTextColor() }}
        >
          {label}
        </Text>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    borderWidth: 1,
  },
});
