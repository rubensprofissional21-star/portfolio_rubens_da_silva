/**
 * Narrative Immersive - Narrativa com efeitos visuais épicos
 */

import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { visualEffectsTheme } from '@/lib/theme/visual-effects';
import type { NPC, RoomTheme } from '@/lib/domain/types';

interface NarrativeImmersiveProps {
  narrative: string;
  npcs: NPC[];
  theme: RoomTheme;
}

export function NarrativeImmersive({ narrative, npcs, theme }: NarrativeImmersiveProps) {
  const themeColors = visualEffectsTheme[theme as keyof typeof visualEffectsTheme] || visualEffectsTheme.medieval;

  const getNPCEmoji = (index: number) => {
    const emojis = ['🧙', '🗡️', '🏹', '⚔️', '🛡️', '👑'];
    return emojis[index % emojis.length];
  };

  return (
    <ScrollView className="flex-1 p-4 gap-4" showsVerticalScrollIndicator={false}>
      {/* Narrative Text */}
      <View
        className="rounded-lg p-4 gap-3"
        style={{
          backgroundColor: 'rgba(0, 0, 0, 0.3)',
          borderLeftWidth: 4,
          borderLeftColor: themeColors.accentColor,
        }}
      >
        <Text className="text-xs font-bold uppercase tracking-widest" style={{ color: themeColors.accentColor }}>
          📖 Narrativa
        </Text>
        <Text className="text-sm leading-relaxed" style={{ color: themeColors.textColor }}>
          {narrative || 'Aguardando narrativa do Mestre...'}
        </Text>
      </View>

      {/* NPCs Section */}
      {npcs.length > 0 && (
        <View className="gap-3">
          <Text className="text-xs font-bold uppercase tracking-widest" style={{ color: themeColors.accentColor }}>
            🎭 Personagens na Cena
          </Text>
          {npcs.map((npc, index) => (
            <View
              key={npc.id}
              className="rounded-lg p-3 gap-2"
              style={{
                backgroundColor: 'rgba(100, 100, 150, 0.3)',
                borderLeftWidth: 3,
                borderLeftColor: themeColors.accentColor,
              }}
            >
              <View className="flex-row items-center gap-2">
                <Text className="text-2xl">{getNPCEmoji(index)}</Text>
                <View className="flex-1">
                  <Text className="font-bold text-sm" style={{ color: themeColors.accentColor }}>
                    {npc.name}
                  </Text>
                  <Text className="text-xs" style={{ color: themeColors.textColor }}>
                    {npc.personality}
                  </Text>
                </View>
              </View>
              <Text className="text-xs leading-relaxed" style={{ color: themeColors.textColor }}>
                {npc.backstory}
              </Text>
              {npc.currentMood && (
                <Text className="text-xs italic" style={{ color: themeColors.accentColor }}>
                  Humor: {npc.currentMood}
                </Text>
              )}
            </View>
          ))}
        </View>
      )}

      {/* Scene Description */}
      <View
        className="rounded-lg p-4 gap-2"
        style={{
          backgroundColor: 'rgba(100, 100, 150, 0.2)',
          borderWidth: 1,
          borderColor: themeColors.borderColor,
        }}
      >
        <Text className="text-xs font-bold uppercase tracking-widest" style={{ color: themeColors.accentColor }}>
          🌍 Ambiente
        </Text>
        <Text className="text-xs leading-relaxed" style={{ color: themeColors.textColor }}>
          Você está em um local misterioso, cheio de possibilidades. Cada ação sua pode mudar o curso da história...
        </Text>
      </View>
    </ScrollView>
  );
}
