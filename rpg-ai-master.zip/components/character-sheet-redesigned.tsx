/**
 * Character Sheet Redesigned - Ficha de personagem com estilo épico
 */

import React from 'react';
import { View, Text, ScrollView, Dimensions } from 'react-native';
import { type Character } from '@/lib/domain/types';

interface CharacterSheetRedesignedProps {
  character: Character;
}

export function CharacterSheetRedesigned({ character }: CharacterSheetRedesignedProps) {
  const screenWidth = Dimensions.get('window').width;

  const ProgressBar = ({ current, max, color, label }: { current: number; max: number; color: string; label: string }) => {
    const percentage = (current / max) * 100;
    return (
      <View className="gap-1 mb-3">
        <View className="flex-row justify-between items-center">
          <Text className="text-purple-200 text-sm font-semibold">{label}</Text>
          <Text className="text-purple-300 text-xs">{current}/{max}</Text>
        </View>
        <View className="h-2 bg-slate-700 rounded-full overflow-hidden border border-purple-600">
          <View
            style={{
              width: `${percentage}%`,
              backgroundColor: color,
            }}
            className="h-full"
          />
        </View>
      </View>
    );
  };

  return (
    <ScrollView className="flex-1 bg-gradient-to-b from-slate-900 to-slate-950" showsVerticalScrollIndicator={false}>
      <View className="px-4 py-6 gap-6">
        {/* Header */}
        <View className="items-center gap-2 border-b border-purple-700 pb-4">
          <Text className="text-2xl font-bold text-purple-300">{character.name}</Text>
          <Text className="text-sm text-purple-400">{character.class} • Nível {character.level}</Text>
          <Text className="text-xs text-purple-500">XP: {character.experience}/{character.experience + 1000}</Text>
        </View>

        {/* Stats */}
        <View className="gap-3">
          <Text className="text-lg font-bold text-purple-300">⚔️ ATRIBUTOS</Text>
          <View className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg p-4 border border-purple-600">
            <View className="grid grid-cols-3 gap-3">
              {[
                { label: 'FOR', value: character.attributes.strength },
                { label: 'DES', value: character.attributes.dexterity },
                { label: 'CON', value: character.attributes.constitution },
                { label: 'INT', value: character.attributes.intelligence },
                { label: 'SAB', value: character.attributes.wisdom },
                { label: 'CAR', value: character.attributes.charisma },
              ].map((attr) => (
                <View key={attr.label} className="items-center bg-slate-700 rounded-lg p-3 border border-purple-600">
                  <Text className="text-purple-300 text-xs font-bold">{attr.label}</Text>
                  <Text className="text-purple-100 text-lg font-bold mt-1">{attr.value}</Text>
                </View>
              ))}
            </View>
          </View>
        </View>

        {/* Health & Mana */}
        <View className="gap-3">
          <Text className="text-lg font-bold text-purple-300">❤️ RECURSOS</Text>
          <View className="bg-gradient-to-br from-slate-800 to-slate-900 rounded-lg p-4 border border-purple-600 gap-4">
            <ProgressBar current={character.health} max={character.maxHealth} color="#ef4444" label="Vida" />
            <ProgressBar current={character.mana} max={character.maxMana} color="#3b82f6" label="Mana" />
            <ProgressBar current={character.experience} max={1000} color="#8b5cf6" label="Experiência" />
          </View>
        </View>

        {/* Inventory */}
        {character.inventory && character.inventory.length > 0 && (
          <View className="gap-3">
            <Text className="text-lg font-bold text-purple-300">🎒 INVENTÁRIO</Text>
            <View className="gap-2">
              {character.inventory.map((item, idx) => (
                <View key={idx} className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-lg p-3 border border-purple-600 flex-row items-center gap-3">
                  <Text className="text-lg">{item.rarity === 'legendary' ? '⭐' : item.rarity === 'rare' ? '✨' : '📦'}</Text>
                  <View className="flex-1">
                    <Text className="text-purple-200 font-semibold text-sm">{item.name}</Text>
                    <Text className="text-purple-400 text-xs">{item.rarity}</Text>
                  </View>
                </View>
              ))}
            </View>
          </View>
        )}
      </View>
    </ScrollView>
  );
}
