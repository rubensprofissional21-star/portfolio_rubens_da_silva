/**
 * VideoconferenceView - Componente para exibir videoconferência Jitsi Meet
 */

import React, { useEffect, useState } from 'react';
import { View, Text, Pressable, ActivityIndicator, Platform } from 'react-native';
import { useVideoconference } from '@/hooks/use-videoconference';
import { useColors } from '@/hooks/use-colors';
import { VideoConferenceConfig } from '@/lib/services/videoconference-service';
import { cn } from '@/lib/utils';

interface VideoconferenceViewProps {
  config: VideoConferenceConfig;
  onDisconnect?: () => void;
  className?: string;
}

export function VideoconferenceView({
  config,
  onDisconnect,
  className,
}: VideoconferenceViewProps) {
  const { state, isInitializing, initialize, disconnect, toggleAudio, toggleVideo, getJitsiUrl } =
    useVideoconference();
  const colors = useColors();
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const initializeVideoconference = async () => {
      try {
        await initialize(config);
        setIsReady(true);
      } catch (error) {
        console.error('Erro ao inicializar videoconferência:', error);
      }
    };

    initializeVideoconference();

    return () => {
      disconnect();
    };
  }, [config, initialize, disconnect]);

  const handleDisconnect = async () => {
    await disconnect();
    onDisconnect?.();
  };

  const handleToggleAudio = async () => {
    await toggleAudio(!state.isAudioMuted);
  };

  const handleToggleVideo = async () => {
    await toggleVideo(!state.isVideoMuted);
  };

  const jitsiUrl = getJitsiUrl();

  if (!jitsiUrl) {
    return (
      <View className="flex-1 items-center justify-center bg-background">
        <Text className="text-foreground">Erro ao carregar videoconferência</Text>
      </View>
    );
  }

  return (
    <View className={cn('flex-1 bg-background', className)}>
      {/* Loading State */}
      {isInitializing && (
        <View className="absolute inset-0 items-center justify-center bg-background/80 z-50">
          <ActivityIndicator size="large" color={colors.primary} />
          <Text className="mt-4 text-foreground">Conectando...</Text>
        </View>
      )}

      {/* Jitsi Meet Embed (Web only for now) */}
      {Platform.OS === 'web' && isReady && (
        <View className="flex-1 bg-background">
          {/* Jitsi Meet será carregado via iframe em web */}
          <Text className="text-foreground p-4">
            Videoconferência carregada: {config.roomId}
          </Text>
        </View>
      )}

      {/* Mobile Placeholder (Jitsi SDK integration would go here) */}
      {Platform.OS !== 'web' && (
        <View className="flex-1 items-center justify-center gap-4">
          <View className="w-full h-1/2 bg-surface rounded-lg border border-border items-center justify-center">
            <Text className="text-2xl mb-2">📹</Text>
            <Text className="text-foreground font-semibold">Videoconferência</Text>
            <Text className="text-xs text-muted mt-2">
              {config.displayName}
            </Text>
          </View>

          {/* Participant Info */}
          <View className="bg-surface rounded-lg p-4 border border-border w-full">
            <Text className="text-sm font-semibold text-foreground mb-2">
              Participantes: {state.participantCount}
            </Text>
            <View className="flex-row gap-2">
              <View className="flex-1">
                <Text className="text-xs text-muted">Áudio</Text>
                <Text className="text-sm font-medium text-foreground">
                  {state.isAudioMuted ? '🔇 Mudo' : '🔊 Ativo'}
                </Text>
              </View>
              <View className="flex-1">
                <Text className="text-xs text-muted">Vídeo</Text>
                <Text className="text-sm font-medium text-foreground">
                  {state.isVideoMuted ? '📹 Desligado' : '📹 Ligado'}
                </Text>
              </View>
            </View>
          </View>
        </View>
      )}

      {/* Controls */}
      {isReady && (
        <View className="bg-surface border-t border-border p-4 flex-row gap-2 items-center justify-center">
          <Pressable
            onPress={handleToggleAudio}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.7 : 1,
                backgroundColor: state.isAudioMuted ? '#EF4444' : colors.primary,
              },
            ]}
            className="flex-1 flex-row items-center justify-center gap-2 p-3 rounded-lg"
          >
            <Text className="text-lg">
              {state.isAudioMuted ? '🔇' : '🔊'}
            </Text>
            <Text
              className="font-semibold"
              style={{ color: colors.background }}
            >
              {state.isAudioMuted ? 'Ativar' : 'Desativar'} Áudio
            </Text>
          </Pressable>

          <Pressable
            onPress={handleToggleVideo}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.7 : 1,
                backgroundColor: state.isVideoMuted ? '#EF4444' : colors.primary,
              },
            ]}
            className="flex-1 flex-row items-center justify-center gap-2 p-3 rounded-lg"
          >
            <Text className="text-lg">
              {state.isVideoMuted ? '📹' : '📹'}
            </Text>
            <Text
              className="font-semibold"
              style={{ color: colors.background }}
            >
              {state.isVideoMuted ? 'Ativar' : 'Desativar'} Vídeo
            </Text>
          </Pressable>

          <Pressable
            onPress={handleDisconnect}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.7 : 1,
                backgroundColor: '#EF4444',
              },
            ]}
            className="flex-1 flex-row items-center justify-center gap-2 p-3 rounded-lg"
          >
            <Text className="text-lg">📞</Text>
            <Text className="font-semibold text-background">
              Desconectar
            </Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}
