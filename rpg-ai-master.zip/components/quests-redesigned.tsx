/**
 * Quests Redesigned - Quests com estilo épico de RPG
 */

import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { type Quest } from '@/lib/domain/types';

interface QuestsRedesignedProps {
  quests: Quest[];
}

export function QuestsRedesigned({ quests }: QuestsRedesignedProps) {
  const getQuestStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return { bg: 'from-yellow-900 to-yellow-800', border: 'border-yellow-600', icon: '🔥' };
      case 'completed':
        return { bg: 'from-green-900 to-green-800', border: 'border-green-600', icon: '✅' };
      case 'failed':
        return { bg: 'from-red-900 to-red-800', border: 'border-red-600', icon: '❌' };
      default:
        return { bg: 'from-purple-900 to-purple-800', border: 'border-purple-600', icon: '❓' };
    }
  };

  return (
    <ScrollView className="flex-1 bg-gradient-to-b from-slate-900 to-slate-950" showsVerticalScrollIndicator={false}>
      <View className="px-4 py-6 gap-4">
        <Text className="text-lg font-bold text-purple-300 mb-2">⚔️ QUESTS</Text>

        {quests.length === 0 ? (
          <View className="items-center justify-center py-8">
            <Text className="text-purple-400 text-center text-sm">Nenhuma quest disponível</Text>
          </View>
        ) : (
          quests.map((quest) => {
            const statusColor = getQuestStatusColor(quest.status);
            const totalObjectives = quest.objectives.length;
            const progress = quest.progress * 100;

            return (
              <View
                key={quest.id}
                className={`bg-gradient-to-br ${statusColor.bg} rounded-lg border-l-4 ${statusColor.border} overflow-hidden`}
              >
                <View className="p-4 gap-3">
                  {/* Header */}
                  <View className="flex-row items-start gap-3">
                    <Text className="text-2xl">{statusColor.icon}</Text>
                    <View className="flex-1">
                      <Text className="text-purple-100 font-bold text-base">{quest.title}</Text>
                      <Text className="text-purple-300 text-xs mt-1">{quest.description}</Text>
                    </View>
                  </View>

                  {/* Objectives */}
                  <View className="gap-2 mt-2">
                    <Text className="text-purple-200 text-xs font-semibold">OBJETIVOS</Text>
                    {quest.objectives.map((obj, idx) => (
                      <View key={idx} className="flex-row items-center gap-2">
                        <Text>
                          {idx < Math.floor(quest.objectives.length * quest.progress) ? '✅' : '⭕'}
                        </Text>
                        <Text className={`text-sm ${idx < Math.floor(quest.objectives.length * quest.progress) ? 'text-purple-400 line-through' : 'text-purple-200'}`}>
                          {obj}
                        </Text>
                      </View>
                    ))}
                  </View>

                  {/* Progress Bar */}
                  <View className="gap-1 mt-2">
                    <View className="flex-row justify-between items-center">
                      <Text className="text-purple-300 text-xs font-semibold">PROGRESSO</Text>
                      <Text className="text-purple-400 text-xs">{Math.floor(quest.objectives.length * quest.progress)}/{totalObjectives}</Text>
                    </View>
                    <View className="h-2 bg-slate-700 rounded-full overflow-hidden border border-purple-600">
                      <View
                        style={{ width: `${progress}%` }}
                        className="h-full bg-gradient-to-r from-yellow-500 to-yellow-400"
                      />
                    </View>
                  </View>

                  {/* Rewards */}
                  {quest.rewards && quest.rewards.length > 0 && (
                    <View className="gap-2 mt-3 pt-3 border-t border-purple-700">
                      <Text className="text-purple-200 text-xs font-semibold">RECOMPENSAS</Text>
                      <View className="flex-row flex-wrap gap-2">
                        {quest.rewards.map((reward, idx) => (
                          <View key={idx} className="bg-slate-800 rounded-lg px-3 py-1 border border-purple-600">
                            <Text className="text-purple-300 text-xs font-semibold">
                              {reward.type === 'experience' && `⭐ ${reward.amount} XP`}
                              {reward.type === 'gold' && `💰 ${reward.amount} Ouro`}
                              {reward.type === 'item' && `📦 ${reward.item?.name || 'Item'}`}
                            </Text>
                          </View>
                        ))}
                      </View>
                    </View>
                  )}

                  {/* Difficulty */}
                  <View className="flex-row items-center gap-2 mt-2">
                    <Text className="text-purple-300 text-xs font-semibold">DIFICULDADE:</Text>
                    <Text className={`text-xs font-bold ${
                      quest.difficulty === 'easy' ? 'text-green-400' :
                      quest.difficulty === 'normal' ? 'text-yellow-400' :
                      'text-red-400'
                    }`}>
                      {quest.difficulty === 'easy' ? '🟢 Fácil' :
                       quest.difficulty === 'normal' ? '🟡 Normal' :
                       '🔴 Difícil'}
                    </Text>
                  </View>
                </View>
              </View>
            );
          })
        )}
      </View>
    </ScrollView>
  );
}
