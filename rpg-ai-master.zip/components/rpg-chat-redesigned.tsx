/**
 * RPG Chat Redesigned - Chat com estilo épico de RPG
 * Mensagens narrativas, efeitos visuais, animações
 */

import React, { useRef, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, TextInput as RNTextInput, ActivityIndicator } from 'react-native';
import { useColors } from '@/hooks/use-colors';

export interface ChatMessage {
  id: string;
  sender: 'player' | 'master';
  content: string;
  timestamp: number;
  type?: 'narrative' | 'dialogue' | 'action' | 'event';
}

interface RPGChatRedesignedProps {
  messages: ChatMessage[];
  onSendMessage: (message: string) => void;
  onQuickAction: (action: string) => void;
  isLoading?: boolean;
  aiLoading?: boolean;
  playerMessage: string;
  onPlayerMessageChange: (text: string) => void;
}

export function RPGChatRedesigned({
  messages,
  onSendMessage,
  onQuickAction,
  isLoading = false,
  aiLoading = false,
  playerMessage,
  onPlayerMessageChange,
}: RPGChatRedesignedProps) {
  const colors = useColors();
  const scrollViewRef = useRef<ScrollView>(null);

  useEffect(() => {
    setTimeout(() => {
      scrollViewRef.current?.scrollToEnd({ animated: true });
    }, 100);
  }, [messages]);

  const handleSend = () => {
    if (playerMessage.trim()) {
      onSendMessage(playerMessage);
    }
  };

  const getMessageStyle = (message: ChatMessage) => {
    if (message.sender === 'player') {
      return {
        container: 'items-end',
        bubble: 'bg-gradient-to-l from-blue-600 to-blue-500 rounded-3xl rounded-tr-sm',
        text: 'text-white',
      };
    } else {
      return {
        container: 'items-start',
        bubble: 'bg-gradient-to-r from-purple-900 to-purple-800 rounded-3xl rounded-tl-sm border border-purple-600',
        text: 'text-purple-100',
      };
    }
  };

  const getMasterPrefix = (type?: string) => {
    switch (type) {
      case 'narrative':
        return '📖 ';
      case 'dialogue':
        return '🗣️ ';
      case 'action':
        return '⚔️ ';
      case 'event':
        return '✨ ';
      default:
        return '🧙 ';
    }
  };

  return (
    <View className="flex-1 flex-col bg-gradient-to-b from-slate-900 to-slate-950">
      {/* Messages */}
      <ScrollView
        ref={scrollViewRef}
        className="flex-1 px-4 py-4"
        contentContainerStyle={{ flexGrow: 1, justifyContent: 'flex-end' }}
        showsVerticalScrollIndicator={false}
      >
        {messages.length === 0 ? (
          <View className="items-center justify-center py-8">
            <Text className="text-purple-400 text-center text-sm">
              Aguardando o Mestre de IA...
            </Text>
          </View>
        ) : (
          messages.map((msg) => {
            const style = getMessageStyle(msg);
            return (
              <View key={msg.id} className={`mb-4 ${style.container}`}>
                <View className={`max-w-xs px-4 py-3 ${style.bubble}`}>
                  {msg.sender === 'master' && (
                    <Text className="text-purple-300 text-xs font-bold mb-1">
                      {getMasterPrefix(msg.type)}MESTRE
                    </Text>
                  )}
                  <Text className={`text-sm leading-relaxed ${style.text}`}>
                    {msg.content}
                  </Text>
                  <Text className={`text-xs mt-2 ${msg.sender === 'player' ? 'text-blue-200' : 'text-purple-300'}`}>
                    {new Date(msg.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
              </View>
            );
          })
        )}

        {aiLoading && (
          <View className="items-start mb-4">
            <View className="bg-gradient-to-r from-purple-900 to-purple-800 rounded-3xl rounded-tl-sm border border-purple-600 px-4 py-3">
              <View className="flex-row items-center gap-2">
                <ActivityIndicator size="small" color="#c084fc" />
                <Text className="text-purple-300 text-sm">Mestre está pensando...</Text>
              </View>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Input Area */}
      <View className="border-t border-purple-700 bg-gradient-to-b from-slate-800 to-slate-900 px-4 py-3 gap-3">
        {/* Quick Actions */}
        <View className="flex-row gap-2 flex-wrap">
          {[
            { icon: '⚔️', label: 'Atacar', action: '⚔️ Atacar' },
            { icon: '🛡️', label: 'Defender', action: '🛡️ Defender' },
            { icon: '💬', label: 'Conversar', action: '💬 Conversar' },
            { icon: '🔍', label: 'Investigar', action: '🔍 Investigar' },
          ].map((btn) => (
            <Pressable
              key={btn.label}
              onPress={() => onQuickAction(btn.action)}
              disabled={isLoading || aiLoading}
              style={({ pressed }) => [
                {
                  opacity: pressed ? 0.8 : 1,
                  transform: [{ scale: pressed ? 0.95 : 1 }],
                },
              ]}
              className="bg-gradient-to-b from-purple-700 to-purple-800 border border-purple-600 rounded-lg px-3 py-2 flex-row items-center gap-1"
            >
              <Text className="text-lg">{btn.icon}</Text>
              <Text className="text-purple-100 text-xs font-semibold">{btn.label}</Text>
            </Pressable>
          ))}
        </View>

        {/* Message Input */}
        <View className="flex-row gap-2 items-center">
          <RNTextInput
            placeholder="Digite sua ação..."
            placeholderTextColor="#9ca3af"
            value={playerMessage}
            onChangeText={onPlayerMessageChange}
            editable={!isLoading && !aiLoading}
            className="flex-1 bg-gradient-to-b from-slate-700 to-slate-800 border border-purple-600 rounded-lg px-4 py-3 text-white"
            style={{ color: '#fff' }}
          />
          <Pressable
            onPress={handleSend}
            disabled={isLoading || aiLoading || !playerMessage.trim()}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.8 : 1,
                transform: [{ scale: pressed ? 0.95 : 1 }],
              },
            ]}
            className="bg-gradient-to-b from-blue-600 to-blue-700 border border-blue-500 rounded-lg px-4 py-3 items-center justify-center"
          >
            {isLoading ? (
              <ActivityIndicator size="small" color="#fff" />
            ) : (
              <Text className="text-white font-bold text-lg">→</Text>
            )}
          </Pressable>
        </View>
      </View>
    </View>
  );
}
