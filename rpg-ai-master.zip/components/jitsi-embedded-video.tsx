/**
 * Jitsi Embedded Video Component
 * Integra Jitsi Meet diretamente no app usando iframe
 */

import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Pressable, Platform } from 'react-native';
import { useColors } from '@/hooks/use-colors';

interface JitsiEmbeddedVideoProps {
  roomName: string;
  displayName: string;
  onReady?: () => void;
  onError?: (error: Error) => void;
  height?: number | string;
  containerClassName?: string;
}

/**
 * Componente de videoconferência integrado com Jitsi Meet
 * Funciona em web usando iframe
 * Em mobile, usa WebView (se disponível) ou fallback
 */
export function JitsiEmbeddedVideo({
  roomName,
  displayName,
  onReady,
  onError,
  height = 400,
  containerClassName = '',
}: JitsiEmbeddedVideoProps) {
  const colors = useColors();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (Platform.OS === 'web') {
      initializeJitsiWeb();
    }
  }, [roomName, displayName]);

  /**
   * Inicializar Jitsi Meet para web
   */
  const initializeJitsiWeb = () => {
    try {
      setIsLoading(true);
      setError(null);

      // Gerar URL do Jitsi Meet com configurações
      const jitsiUrl = generateJitsiUrl();

      // Criar iframe dinamicamente
      const iframe = document.createElement('iframe');
      iframe.src = jitsiUrl;
      iframe.style.width = '100%';
      iframe.style.height = typeof height === 'number' ? `${height}px` : height;
      iframe.style.border = 'none';
      iframe.style.borderRadius = '8px';
      iframe.allow = 'camera; microphone; display-capture';
      iframe.allowFullscreen = true;

      // Monitorar carregamento
      iframe.onload = () => {
        setIsLoading(false);
        onReady?.();
      };

      iframe.onerror = () => {
        const err = new Error('Erro ao carregar Jitsi Meet');
        setError(err.message);
        onError?.(err);
        setIsLoading(false);
      };

      // Adicionar ao DOM
      if (iframeRef.current) {
        iframeRef.current.innerHTML = '';
        iframeRef.current.appendChild(iframe);
      }
    } catch (err) {
      const error = err instanceof Error ? err : new Error(String(err));
      setError(error.message);
      onError?.(error);
      setIsLoading(false);
    }
  };

  /**
   * Gerar URL do Jitsi Meet com configurações
   */
  const generateJitsiUrl = (): string => {
    const baseUrl = 'https://meet.jit.si';
    const sanitizedRoomName = roomName.replace(/[^a-zA-Z0-9]/g, '');

    // Configurações do Jitsi Meet
    const config = {
      // Interface
      'config.toolbarButtons': [
        'microphone',
        'camera',
        'closedcaptions',
        'desktop',
        'fullscreen',
        'fodeviceselection',
        'hangup',
        'profile',
        'chat',
        'recording',
        'livestreaming',
        'etherpad',
        'sharedvideo',
        'settings',
        'raisehand',
        'videoquality',
        'filmstrip',
        'invite',
        'feedback',
        'stats',
        'shortcuts',
        'tileview',
        'videobackgroundblur',
        'download',
        'help',
        'mute-everyone',
        'e2ee',
      ],
      'config.prejoinPageEnabled': false,
      'config.startAudioMuted': false,
      'config.startVideoMuted': false,
      'config.enableWelcomePage': false,
      'config.disableSimulcast': false,

      // Experiência
      'config.enableNoAudioDetection': true,
      'config.enableNoisyMicDetection': true,
      'config.enableInsecureRoomNameWarning': false,

      // Layout
      'config.filmStripOnly': false,
      'config.hideConferenceSubject': false,
      'config.hideConferenceTimer': false,
      'config.hideParticipantsStats': false,

      // Segurança
      'config.requireDisplayName': true,
      'config.disableRemoteMute': false,

      // Informações do usuário
      'userInfo.displayName': displayName,
    };

    // Construir query string
    const params = new URLSearchParams();
    Object.entries(config).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        params.append(key, JSON.stringify(value));
      } else {
        params.append(key, String(value));
      }
    });

    return `${baseUrl}/${sanitizedRoomName}?${params.toString()}`;
  };

  /**
   * Recarregar iframe
   */
  const handleReload = () => {
    initializeJitsiWeb();
  };

  return (
    <View className={`bg-background rounded-lg overflow-hidden ${containerClassName}`}>
      {/* Loading State */}
      {isLoading && (
        <View
          style={{ height: typeof height === 'number' ? height : 400 }}
          className="bg-surface items-center justify-center gap-2"
        >
          <Text className="text-lg text-foreground">📹 Carregando Jitsi Meet...</Text>
          <Text className="text-sm text-muted">Aguarde a videoconferência carregar</Text>
        </View>
      )}

      {/* Error State */}
      {error && (
        <View
          style={{ height: typeof height === 'number' ? height : 400 }}
          className="bg-error/10 border border-error rounded-lg items-center justify-center gap-3 p-4"
        >
          <Text className="text-lg text-error font-semibold">❌ Erro ao Carregar</Text>
          <Text className="text-sm text-error text-center">{error}</Text>
          <Pressable
            onPress={handleReload}
            style={({ pressed }) => [
              {
                opacity: pressed ? 0.7 : 1,
                backgroundColor: '#EF4444',
              },
            ]}
            className="px-6 py-2 rounded-lg"
          >
            <Text className="text-white font-semibold">🔄 Tentar Novamente</Text>
          </Pressable>
        </View>
      )}

      {/* Jitsi Iframe Container (Web only) */}
      {Platform.OS === 'web' && (
        <div
          ref={iframeRef as any}
          style={{
            width: '100%',
            height: typeof height === 'number' ? `${height}px` : height,
            display: isLoading || error ? 'none' : 'block',
          }}
        />
      )}

      {/* Mobile Fallback */}
      {Platform.OS !== 'web' && (
        <View
          style={{ height: typeof height === 'number' ? height : 400 }}
          className="bg-surface items-center justify-center gap-2 p-4"
        >
          <Text className="text-lg text-foreground">📱 Videoconferência</Text>
          <Text className="text-sm text-muted text-center">
            Use o navegador web para acessar a videoconferência completa
          </Text>
          <Text className="text-xs text-muted mt-2">
            Abra em: https://meet.jit.si/{roomName.replace(/[^a-zA-Z0-9]/g, '')}
          </Text>
        </View>
      )}
    </View>
  );
}

/**
 * Hook para gerenciar Jitsi Meet integrado
 */
export function useJitsiEmbedded(roomName: string, displayName: string) {
  const [isReady, setIsReady] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  return {
    isReady,
    error,
    onReady: () => setIsReady(true),
    onError: (err: Error) => setError(err),
  };
}
