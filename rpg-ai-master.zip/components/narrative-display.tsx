/**
 * Narrative Display - Exibição épica da narrativa com formatação RPG
 */

import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useRPGTheme } from './rpg-theme-provider';
import { type NarrativeEvent } from '@/lib/domain/types';

interface NarrativeDisplayProps {
  events: NarrativeEvent[];
  theme?: string;
}

export function NarrativeDisplay({ events, theme }: NarrativeDisplayProps) {
  const rpgTheme = useRPGTheme();

  const getEventColor = (type: string) => {
    switch (type) {
      case 'narration':
        return rpgTheme.colors.text;
      case 'npc_action':
        return rpgTheme.colors.secondary;
      case 'player_action':
        return rpgTheme.colors.accent;
      case 'quest_update':
        return rpgTheme.colors.info;
      case 'event':
        return rpgTheme.colors.warning;
      default:
        return rpgTheme.colors.text;
    }
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'narration':
        return '📖';
      case 'npc_action':
        return '🎭';
      case 'player_action':
        return '⚔️';
      case 'quest_update':
        return '⚡';
      case 'event':
        return '✨';
      default:
        return '•';
    }
  };

  return (
    <ScrollView
      className="flex-1 p-4"
      style={{ backgroundColor: rpgTheme.colors.narrativeBackground }}
      contentContainerStyle={{ paddingBottom: 20 }}
    >
      {events.length === 0 ? (
        <View className="flex-1 items-center justify-center py-8">
          <Text
            className="text-center text-lg"
            style={{ color: rpgTheme.colors.textSecondary }}
          >
            Aguardando o Mestre de IA...
          </Text>
        </View>
      ) : (
        events.map((event, index) => (
          <View
            key={index}
            className="mb-4 p-3 rounded-lg border-l-4"
            style={{
              backgroundColor: rpgTheme.colors.npcBackground,
              borderLeftColor: getEventColor(event.type),
            }}
          >
            {/* Header com ícone e tipo */}
            <View className="flex-row items-center mb-2">
              <Text className="text-xl mr-2">{getEventIcon(event.type)}</Text>
              <Text
                className="text-xs font-bold uppercase tracking-wider"
                style={{ color: getEventColor(event.type) }}
              >
                {event.type.replace('_', ' ')}
              </Text>
            </View>

            {/* Conteúdo da narrativa */}
            <Text
              className="text-sm leading-relaxed"
              style={{ color: rpgTheme.colors.text }}
            >
              {event.content}
            </Text>

            {/* Timestamp */}
            <Text
              className="text-xs mt-2"
              style={{ color: rpgTheme.colors.textSecondary }}
            >
              {new Date(event.timestamp).toLocaleTimeString('pt-BR', {
                hour: '2-digit',
                minute: '2-digit',
              })}
            </Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}
