#!/usr/bin/env python3
from PIL import Image
import os

os.chdir('/home/ubuntu/rpg-ai-master/assets/images')

images = [
    'hero-banner.png',
    'card-create-room.png',
    'card-join-room.png',
    'card-ai-master.png'
]

for img_name in images:
    if os.path.exists(img_name):
        print(f"Comprimindo {img_name}...")
        img = Image.open(img_name)
        
        # Redimensionar para max 800px mantendo aspect ratio
        img.thumbnail((800, 800), Image.Resampling.LANCZOS)
        
        # Converter para RGB se necessário (remove alpha)
        if img.mode in ('RGBA', 'LA', 'P'):
            background = Image.new('RGB', img.size, (255, 255, 255))
            background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
            img = background
        
        # Salvar como JPEG com compressão
        jpg_name = img_name.replace('.png', '.jpg')
        img.save(jpg_name, 'JPEG', quality=75, optimize=True)
        
        size_kb = os.path.getsize(jpg_name) / 1024
        print(f"✓ {jpg_name}: {size_kb:.1f} KB")
        
        # Remover PNG original
        os.remove(img_name)
        print(f"  Removido {img_name}")

print("\nCompressão concluída!")
