/**
 * OpenAI Router - Rota tRPC para processar requisições da OpenAI no backend
 * Mantém a API Key segura no servidor
 */

import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";

export const openaiRouter = router({
  /**
   * Gerar narrativa inicial
   */
  generateNarrative: publicProcedure
    .input(
      z.object({
        theme: z.string(),
        difficulty: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
          throw new Error("OpenAI API Key não configurada no servidor");
        }

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
              {
                role: "system",
                content: `Você é um Mestre de Dungeons & Dragons experiente. Crie uma narrativa épica e imersiva.`,
              },
              {
                role: "user",
                content: `Crie uma narrativa inicial para uma sessão de RPG com tema ${input.theme} e dificuldade ${input.difficulty}. Máximo 3 parágrafos.`,
              },
            ],
            temperature: 0.8,
            max_tokens: 500,
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(`OpenAI Error: ${error.error?.message || "Unknown error"}`);
        }

        const data = await response.json();
        return {
          success: true,
          narrative: data.choices[0]?.message?.content || "Erro ao gerar narrativa",
        };
      } catch (error) {
        console.error("Erro ao gerar narrativa:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido",
        };
      }
    }),

  /**
   * Gerar NPCs
   */
  generateNPCs: publicProcedure
    .input(
      z.object({
        theme: z.string(),
        count: z.number().default(2),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
          throw new Error("OpenAI API Key não configurada no servidor");
        }

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
              {
                role: "system",
                content: `Você é um criador de personagens RPG. Responda APENAS com JSON válido, sem explicações.`,
              },
              {
                role: "user",
                content: `Crie ${input.count} NPCs para um cenário ${input.theme}. Responda em JSON: {"npcs": [{"name": "...", "personality": "...", "backstory": "...", "currentMood": "..."}]}`,
              },
            ],
            temperature: 0.8,
            max_tokens: 500,
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(`OpenAI Error: ${error.error?.message || "Unknown error"}`);
        }

        const data = await response.json();
        const content = data.choices[0]?.message?.content || "{}";

        try {
          const parsed = JSON.parse(content);
          return {
            success: true,
            npcs: parsed.npcs || [],
          };
        } catch {
          return {
            success: true,
            npcs: [],
          };
        }
      } catch (error) {
        console.error("Erro ao gerar NPCs:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido",
          npcs: [],
        };
      }
    }),

  /**
   * Gerar Quest
   */
  generateQuest: publicProcedure
    .input(
      z.object({
        theme: z.string(),
        difficulty: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
          throw new Error("OpenAI API Key não configurada no servidor");
        }

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
              {
                role: "system",
                content: `Você é um designer de quests RPG. Responda APENAS com JSON válido, sem explicações.`,
              },
              {
                role: "user",
                content: `Crie uma quest para tema ${input.theme} com dificuldade ${input.difficulty}. Responda em JSON: {"quest": {"title": "...", "description": "...", "objectives": ["..."], "rewards": [{"type": "experience", "amount": 100}]}}`,
              },
            ],
            temperature: 0.8,
            max_tokens: 500,
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(`OpenAI Error: ${error.error?.message || "Unknown error"}`);
        }

        const data = await response.json();
        const content = data.choices[0]?.message?.content || "{}";

        try {
          const parsed = JSON.parse(content);
          return {
            success: true,
            quest: parsed.quest || null,
          };
        } catch {
          return {
            success: true,
            quest: null,
          };
        }
      } catch (error) {
        console.error("Erro ao gerar quest:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido",
          quest: null,
        };
      }
    }),

  /**
   * Responder ação do jogador
   */
  respondToAction: publicProcedure
    .input(
      z.object({
        action: z.string(),
        context: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      try {
        const apiKey = process.env.OPENAI_API_KEY;
        if (!apiKey) {
          throw new Error("OpenAI API Key não configurada no servidor");
        }

        const response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
              {
                role: "system",
                content: `Você é um Mestre de RPG épico. Responda às ações dos jogadores de forma criativa e imersiva. Máximo 2-3 parágrafos.`,
              },
              {
                role: "user",
                content: `Contexto: ${input.context}\n\nAção do jogador: ${input.action}\n\nResponda como o Mestre de RPG.`,
              },
            ],
            temperature: 0.8,
            max_tokens: 500,
          }),
        });

        if (!response.ok) {
          const error = await response.json();
          throw new Error(`OpenAI Error: ${error.error?.message || "Unknown error"}`);
        }

        const data = await response.json();
        return {
          success: true,
          response: data.choices[0]?.message?.content || "Erro ao processar ação",
        };
      } catch (error) {
        console.error("Erro ao responder ação:", error);
        return {
          success: false,
          error: error instanceof Error ? error.message : "Erro desconhecido",
          response: "",
        };
      }
    }),
});
